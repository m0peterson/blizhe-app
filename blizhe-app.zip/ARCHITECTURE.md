# ARCHITECTURE — «Ближе»

Короткая фиксация решений. Подробности команд и backlog — в README.

## Стек

React 19 + TypeScript strict + Vite 7 + Vitest + Playwright. CSS Modules,
дизайн-токены в `src/styles/tokens.css` (тёплый фон `#faf6f1`, сливовый `#7b4b57`,
терракотовый `#c1754f`). Новых npm-зависимостей нет.

## Поток данных

```
data/*.json → registry → modules (чистые функции)
                                    ↓
store.tsx (React) → репозитории → KvStore → IndexedDB | memory
                                    ↓
                          экраны ← shared/ui
```

- Контент собирается на этапе сборки (`registry.ts` бросает при невалидных данных).
- Сессия: `filterCards` → `buildQueue` → `createSession` (снимок `queue`) →
  `advance / goBack / finish` → `reapplyConstraints` при восстановлении и смене настроек.
- Случайность только через `rng: () => number`, в тестах подменяется детерминированной.
- Состояния карточки `shown | discussed | skipped | deferred` различаются; пропуск не ответ.
- `goBack` перечитывает без удвоения прогресса; быстрые повторные нажатия блокируются
  локом 400 мс в `SessionScreen`.
- `seenCardIds` пишется при показе, используется как `preferUnseen` для новых сессий.

## Хранилище

- База `blizhe`, хранилище `kv`, версия `DATA_SCHEMA_VERSION = 1`.
- Ключи: preferences / session / saved / meta (seen + contentVersion).
- Ошибка записи пробрасывается наверх; UI показывает предупреждение и не врёт об успехе.
- `clearAllUserData` сносит всё пользовательское, библиотека остаётся.

## PWA

- `sw.js`: кеш оболочки, навигация network-first с офлайн-фолбэком, runtime-кеш ассетов,
  `SKIP_WAITING` только по сообщению, без принудительной перезагрузки.
- `register.ts`: регистрация, события `blizhe:pwa-update` / `blizhe:pwa-ready`,
  `applyPwaUpdate()` только по кнопке пользователя.

## Экраны

Home (быстрый старт «Лёгкий вечер» 5 карточек / Продолжить / PRESETS / своя сессия) →
Session (одна карточка, прогресс i/N, чей ответ, follow-up по действию, choice + «свой ответ»,
«Обсудили» основное, «Пропустить», «Назад», «В избранное», «Сохранить мысль», «Закончить») →
Finish (необязательная одна запись, сессия без записей полноценна) + Topics (библиотека,
поиск, скрытия, статусы) + Our (заметки, избранное, обсудить позже) + Settings
(взрослый раздел 18+ + откровенность, имена, повторы, данные, wipe, install, офлайн/обновление).

## Проверки

- `tests/content-validation` — 12 колод, 120 карточек, дубликаты, ссылки, поля, adult-правила.
- `tests/session-engine` — детерминированная rng, без повторов, фильтры и adult-gating,
  back/двойные нажатия, reapplyConstraints, короткая/пустая библиотека.
- `tests/saved|preferences|search|storage` — чистая логика и миграции без потери заметок.
- `e2e/main-flow|adult-gating|persistence|responsive` — мобильные вьюпорты,
  офлайн после прогрева кеша.
