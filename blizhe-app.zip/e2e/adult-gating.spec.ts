import { expect, test } from '@playwright/test';

test('взрослый контент недоступен без включения: подборки, поиск, восстановление', async ({ page }) => {
  await page.goto('./');

  // Подборка «Близость и желания» заблокирована.
  const preset = page.getByTestId('home-preset-blizost-i-zhelaniya');
  await expect(preset).toBeDisabled();

  // Поиск: взрослые формулировки не показываются.
  await page.getByTestId('nav-topics').click();
  await page.getByTestId('topics-search').fill('близость желания границы откровенно');
  // Либо пусто, либо только невзрослые карточки: проверяем, что откровенных меток нет.
  await expect(page.getByText('Откровенно')).toHaveCount(0);

  // Включаем и выключаем: выключение чистит текущий показ через reapplyConstraints.
  await page.getByTestId('nav-settings').click();
  await page.getByTestId('settings-adult-toggle').click();
  await page.getByTestId('settings-adult-18').click();
  await page.getByTestId('settings-intimacy-frank').click();
  await page.getByRole('button', { name: 'Включить', exact: true }).click();
  await expect(page.getByTestId('settings-adult-toggle')).toHaveAttribute('aria-checked', 'true');

  // После включения подборка доступна.
  await page.getByTestId('nav-home').click();
  await expect(page.getByTestId('home-preset-blizost-i-zhelaniya')).toBeEnabled();

  // Выключаем обратно: подборка снова недоступна.
  await page.getByTestId('nav-settings').click();
  await page.getByTestId('settings-adult-toggle').click();
  await page.getByTestId('nav-home').click();
  await expect(page.getByTestId('home-preset-blizost-i-zhelaniya')).toBeDisabled();
});
