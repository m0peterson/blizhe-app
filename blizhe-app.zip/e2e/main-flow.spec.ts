import { expect, test } from '@playwright/test';

test('новый пользователь: первая карточка без регистрации, 5 карточек, пропуск, сохранённая мысль в «Нашем»', async ({
  page,
}) => {
  await page.goto('./');
  await expect(page.getByTestId('home-start-quick')).toBeVisible();

  await page.getByTestId('home-start-quick').click();
  await expect(page.getByTestId('session-card-prompt')).toBeVisible();
  await expect(page.getByTestId('session-progress')).toContainText('1/5');

  // Пропуск: карточка меняется, прогресс растёт.
  const first = await page.getByTestId('session-card-prompt').innerText();
  await page.getByTestId('session-action-skip').click();
  await expect(page.getByTestId('session-progress')).toContainText('2/5');
  const second = await page.getByTestId('session-card-prompt').innerText();
  expect(second).not.toBe(first);

  // Пауза дольше анти-даблтапа (400 мс), иначе следующее нажатие игнорируется.
  await page.waitForTimeout(450);
  // Обсудили: прогресс дальше.
  await page.getByTestId('session-action-discussed').click();
  await expect(page.getByTestId('session-progress')).toContainText('3/5');

  // Сохранить мысль: диалог, текст, сохранение.
  await page.getByTestId('session-action-save-thought').click();
  await page.getByTestId('session-note-text').fill('Мы решили гулять вместе в субботу');
  await page.getByRole('button', { name: 'Сохранить', exact: true }).click();

  // Добиваем сессию до финала (с паузами под анти-даблтап 400 мс).
  await page.getByTestId('session-action-discussed').click();
  await page.waitForTimeout(450);
  await page.getByTestId('session-action-discussed').click();
  await page.waitForTimeout(450);
  await page.getByTestId('session-action-discussed').click();
  await expect(page.getByTestId('finish-note-text')).toBeVisible({ timeout: 5000 });
  await page.getByTestId('finish-done').click();

  await page.getByTestId('nav-our').click();
  await expect(page.getByText('Мы решили гулять вместе в субботу')).toBeVisible();
});
