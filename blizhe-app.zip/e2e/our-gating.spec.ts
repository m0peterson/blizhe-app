import { expect, test } from '@playwright/test';

// Б1: скрытая тема прячет свои карточки в «Нашем» (избранное и отложенное).
test('скрытая тема убирает её карточки из «Нашего»', async ({ page }) => {
  await page.goto('./');
  await page.getByTestId('nav-topics').click();
  await expect(page.getByTestId('topics-card-byt-01')).toBeVisible();

  await page.getByTestId('topics-fav-byt-01').click();
  await page.getByTestId('topics-defer-byt-02').click();

  await page.getByTestId('nav-our').click();
  await expect(page.getByTestId('our-fav-byt-01')).toBeVisible();
  await expect(page.getByTestId('our-deferred-byt-02')).toBeVisible();

  // Скрываем тему и проверяем, что карточки ушли из «Нашего».
  await page.getByTestId('nav-topics').click();
  await page.getByTestId('topics-hide-deck-byt').click();

  await page.getByTestId('nav-our').click();
  await expect(page.getByTestId('our-fav-byt-01')).toHaveCount(0);
  await expect(page.getByTestId('our-deferred-byt-02')).toHaveCount(0);
});

// Б2: цитата связанной взрослой/скрытой карточки не видна в заметках,
// текст самой заметки сохраняется.
test('заметки прячут цитаты недоступных карточек, но хранят текст', async ({ page }) => {
  await page.goto('./');
  await page.evaluate(
    () =>
      new Promise((resolve, reject) => {
        const req = indexedDB.open('blizhe', 1);
        req.onsuccess = () => {
          const db = req.result;
          const tx = db.transaction('kv', 'readwrite');
          const st = tx.objectStore('kv');
          st.put(
            {
              schemaVersion: 1,
              favorites: [],
              deferred: [],
              notes: [
                {
                  id: 'n-adult',
                  kind: 'learned',
                  text: 'Наша мысль про близость',
                  cardId: 'seks-06',
                  createdAt: 1,
                  updatedAt: 1,
                  done: false,
                },
                {
                  id: 'n-hidden',
                  kind: 'learned',
                  text: 'Наша мысль про быт',
                  cardId: 'byt-01',
                  createdAt: 1,
                  updatedAt: 1,
                  done: false,
                },
              ],
            },
            'blizhe:saved:v1',
          );
          st.put(
            {
              schemaVersion: 1,
              adultEnabled: false,
              intimacyLevel: null,
              hiddenDeckIds: ['byt'],
              hiddenCardIds: [],
              nameA: '',
              nameB: '',
              allowRepeats: false,
            },
            'blizhe:preferences:v1',
          );
          tx.oncomplete = () => {
            db.close();
            resolve(0);
          };
          tx.onerror = () => reject(tx.error ?? new Error('tx failed'));
        };
        req.onerror = () => reject(req.error ?? new Error('open failed'));
      }),
  );
  await page.reload();

  await page.getByTestId('nav-our').click();
  // Тексты заметок видны.
  await expect(page.getByText('Наша мысль про близость')).toBeVisible();
  await expect(page.getByText('Наша мысль про быт')).toBeVisible();
  // Цитаты связанных карточек скрыты фильтрами.
  await expect(page.getByText(/К карточке:/)).toHaveCount(0);
});
