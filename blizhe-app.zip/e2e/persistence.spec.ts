import { expect, test } from '@playwright/test';

test('после перезагрузки: очередь, позиция, прогресс и заметки сохраняются', async ({ page }) => {
  await page.goto('./');
  await page.getByTestId('home-start-quick').click();
  await expect(page.getByTestId('session-card-prompt')).toBeVisible();

  await page.getByTestId('session-action-discussed').click();
  await expect(page.getByTestId('session-progress')).toContainText('2/5');

  await page.getByTestId('session-action-save-thought').click();
  await page.getByTestId('session-note-text').fill('Заметка для проверки перезагрузки');
  await page.getByRole('button', { name: 'Сохранить', exact: true }).click();

  await page.reload();
  // Продолжить доступен, позиция и прогресс восстановлены.
  await expect(page.getByTestId('home-continue')).toBeVisible();
  await page.getByTestId('home-continue').click();
  await expect(page.getByTestId('session-progress')).toContainText('2/5');

  // Нижняя навигация скрыта во время разговора: завершаем сессию штатно,
  // затем проверяем, что заметка сохранилась в «Нашем».
  await page.getByTestId('session-action-finish').click();
  await page.getByRole('dialog').getByRole('button', { name: 'Закончить', exact: true }).click();
  await expect(page.getByTestId('finish-note-text')).toBeVisible();
  await page.getByTestId('finish-done').click();

  await page.getByTestId('nav-our').click();
  await expect(page.getByText('Заметка для проверки перезагрузки')).toBeVisible();
});

test('офлайн-сценарий после прогрева кеша: сессию можно начать и закончить', async ({ page, context }) => {
  await page.goto('./');
  await expect(page.getByTestId('home-start-quick')).toBeVisible();

  // Прогреваем service worker: первая загрузка его только устанавливает,
  // кеш бандлов наполняется на управляемой перезагрузке.
  await page.waitForFunction(() => 'serviceWorker' in navigator, null, { timeout: 15000 });
  await page.reload();
  await expect(page.getByTestId('home-start-quick')).toBeVisible();
  await page.waitForFunction(() => !!navigator.serviceWorker?.controller, null, { timeout: 15000 });

  await context.setOffline(true);
  await page.reload();
  await expect(page.getByTestId('home-start-quick')).toBeVisible({ timeout: 15000 });
  await page.getByTestId('home-start-quick').click();
  await expect(page.getByTestId('session-card-prompt')).toBeVisible({ timeout: 15000 });
  // Проходим все 5 карточек и завершаем сессию, не выходя в сеть
  // (паузы под анти-даблтап 400 мс).
  for (const label of ['2/5', '3/5', '4/5', '5/5']) {
    await page.getByTestId('session-action-discussed').click();
    await expect(page.getByTestId('session-progress')).toContainText(label);
    await page.waitForTimeout(450);
  }
  await page.getByTestId('session-action-discussed').click();
  await expect(page.getByTestId('finish-note-text')).toBeVisible({ timeout: 15000 });
  await page.getByTestId('finish-done').click();
  await expect(page.getByTestId('home-start-quick')).toBeVisible({ timeout: 15000 });
  await context.setOffline(false);
});
