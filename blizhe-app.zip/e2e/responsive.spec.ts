import { expect, test } from '@playwright/test';

const WIDTHS = [320, 375, 390, 430];

for (const width of WIDTHS) {
  test(`ширина ${width}: нет горизонтального скролла, вопрос и кнопки доступны`, async ({ page }) => {
    await page.setViewportSize({ width, height: 800 });
    await page.goto('./');
    await page.getByTestId('home-start-quick').click();
    await expect(page.getByTestId('session-card-prompt')).toBeVisible();

    const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    expect(scrollWidth).toBeLessThanOrEqual(width + 1);

    await expect(page.getByTestId('session-action-discussed')).toBeVisible();
    await expect(page.getByTestId('session-action-skip')).toBeVisible();

    // Ввод заметки с клавиатуры: поле доступно и не прячет кнопки.
    await page.getByTestId('session-action-save-thought').click();
    const input = page.getByTestId('session-note-text');
    await expect(input).toBeVisible();
    await input.fill('Проверка ввода на узком экране');
    await expect(page.getByRole('button', { name: 'Сохранить', exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Сохранить', exact: true }).click();

    const afterScroll = await page.evaluate(() => document.documentElement.scrollWidth);
    expect(afterScroll).toBeLessThanOrEqual(width + 1);
  });
}
