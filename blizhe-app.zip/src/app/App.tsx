import { useEffect, useState } from 'react';
import { StoreProvider, useStore } from './store';
import { BottomNav } from '../shared/ui';
import type { NavKey } from '../shared/ui';
import { HomeScreen } from './screens/HomeScreen';
import { SessionScreen } from './screens/SessionScreen';
import { FinishScreen } from './screens/FinishScreen';
import { TopicsScreen } from './screens/TopicsScreen';
import { OurScreen } from './screens/OurScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import styles from './App.module.css';

export type Screen = 'home' | 'session' | 'finish' | 'topics' | 'our' | 'settings';

function Shell() {
  const { ready, storageMode, storageError, saveError } = useStore();
  const [screen, setScreen] = useState<Screen>('home');
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [offlineReady, setOfflineReady] = useState(false);

  useEffect(() => {
    const onUpdate = () => setUpdateAvailable(true);
    const onReady = () => setOfflineReady(true);
    window.addEventListener('blizhe:pwa-update', onUpdate);
    window.addEventListener('blizhe:pwa-ready', onReady);
    return () => {
      window.removeEventListener('blizhe:pwa-update', onUpdate);
      window.removeEventListener('blizhe:pwa-ready', onReady);
    };
  }, []);

  // Завершённую сессию не показываем как активную.
  const inConversation = screen === 'session' || screen === 'finish';
  const nav: NavKey = screen === 'topics' ? 'topics' : screen === 'our' ? 'our' : screen === 'settings' ? 'settings' : 'home';

  if (!ready) {
    return (
      <div className={styles.layout}>
        <p className={styles.loading}>Загружаем «Ближе»…</p>
      </div>
    );
  }

  return (
    <div className={styles.layout}>
      <main className={styles.main}>
        {storageMode === 'memory' ? (
          <p role="alert" className={`${styles.banner} ${styles.warning}`}>
            Хранилище недоступно: включён временный режим. Прогресс, заметки и избранное не сохранятся
            после закрытия вкладки.
          </p>
        ) : null}
        {storageError ? (
          <p role="alert" className={`${styles.banner} ${styles.warning}`}>
            {storageError}
          </p>
        ) : null}
        {saveError ? (
          <p role="alert" className={`${styles.banner} ${styles.warning}`}>
            {saveError}
          </p>
        ) : null}
        {updateAvailable ? (
          <p className={`${styles.banner} ${styles.info}`}>
            Доступно обновление. Оно применится только когда вы нажмёте кнопку в «Настройках» — разговор
            не прервётся сам.
          </p>
        ) : null}
        {screen === 'home' ? (
          <HomeScreen goSession={() => setScreen('session')} offlineReady={offlineReady} />
        ) : null}
        {screen === 'session' ? (
          <SessionScreen
            goFinish={() => setScreen('finish')}
            goHome={() => setScreen('home')}
          />
        ) : null}
        {screen === 'finish' ? <FinishScreen goHome={() => setScreen('home')} /> : null}
        {screen === 'topics' ? <TopicsScreen /> : null}
        {screen === 'our' ? <OurScreen /> : null}
        {screen === 'settings' ? (
          <SettingsScreen offlineReady={offlineReady} updateAvailable={updateAvailable} />
        ) : null}
      </main>
      {inConversation ? null : (
        <BottomNav
          current={nav}
          onNavigate={(key) => setScreen(key === 'home' ? 'home' : key)}
        />
      )}
    </div>
  );
}

export function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
