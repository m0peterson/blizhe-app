import { useState } from 'react';
import { finish } from '../../modules/session';
import type { NoteKind } from '../../modules/saved';
import { addNote } from '../../modules/saved';
import { useStore } from '../store';
import { Button, TextField } from '../../shared/ui';
import styles from './screens.module.css';

interface FinishScreenProps {
  goHome: () => void;
}

export function FinishScreen({ goHome }: FinishScreenProps) {
  const { session, saved, setSession, updateSaved } = useStore();
  const [kind, setKind] = useState<NoteKind>('learned');
  const [text, setText] = useState('');
  const [savedOnce, setSavedOnce] = useState(false);

  const done = async () => {
    if (session && !session.finished) {
      await setSession(finish(session, Date.now()));
    }
    // Сессия без записей тоже полноценна: очищаем очередь после финала.
    await setSession(null);
    goHome();
  };

  const saveOne = async () => {
    const value = text.trim();
    if (!value || savedOnce) return;
    const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `n-${Date.now()}`;
    const queue = session?.queue ?? [];
    const cardId = queue[session?.index ?? queue.length - 1]?.id ?? queue[queue.length - 1]?.id ?? null;
    await updateSaved(addNote(saved, { kind, text: value, cardId }, Date.now(), id));
    setSavedOnce(true);
    setText('');
  };

  return (
    <div className={styles.screen}>
      <h1 className={styles.title}>Разговор завершён</h1>
      <p className={styles.subtitle}>Сессия без записей тоже полноценна. Этот шаг необязателен.</p>
      <section className={styles.section} aria-label="Сохранить вывод">
        <h2 className={styles.sectionTitle}>Один вывод, желание или договорённость</h2>
        <div className={styles.row} role="group" aria-label="Вид записи">
          <button type="button" data-testid="finish-kind-learned" aria-pressed={kind === 'learned'} className={styles.preset} onClick={() => setKind('learned')}>
            <span className={styles.presetName}>Узнали друг о друге</span>
          </button>
          <button type="button" data-testid="finish-kind-agreement" aria-pressed={kind === 'agreement'} className={styles.preset} onClick={() => setKind('agreement')}>
            <span className={styles.presetName}>Договорились</span>
          </button>
          <button type="button" data-testid="finish-kind-idea" aria-pressed={kind === 'idea'} className={styles.preset} onClick={() => setKind('idea')}>
            <span className={styles.presetName}>Идея подарка или желания</span>
          </button>
        </div>
        <TextField
          label="Запись"
          value={text}
          onChange={setText}
          placeholder="Необязательно. Сохраняется только написанное."
          multiline
          testId="finish-note-text"
        />
        <Button variant="secondary" data-testid="finish-save" onClick={() => void saveOne()} disabled={!text.trim() || savedOnce}>
          {savedOnce ? 'Сохранено' : 'Сохранить вывод'}
        </Button>
      </section>
      <Button variant="primary" data-testid="finish-done" onClick={() => void done()}>
        К началу
      </Button>
    </div>
  );
}
