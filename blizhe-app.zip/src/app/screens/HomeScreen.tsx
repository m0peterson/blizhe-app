import { useMemo, useState } from 'react';
import { PRESETS, decks } from '../../modules/content';
import type { Depth } from '../../modules/content';
import { isComplete, progress } from '../../modules/session';
import type { SessionFilter } from '../../modules/session';
import { useStore } from '../store';
import { startSession } from '../startSession';
import { Button, Chip, Dialog, EmptyState } from '../../shared/ui';
import styles from './screens.module.css';

interface HomeScreenProps {
  goSession: () => void;
  offlineReady: boolean;
}

const COUNTS = [5, 10, 15] as const;

export function HomeScreen({ goSession, offlineReady }: HomeScreenProps) {
  const { prefs, session, meta, setSession } = useStore();
  const [selectedDecks, setSelectedDecks] = useState<string[]>([]);
  const [maxDepth, setMaxDepth] = useState<Depth>('personal');
  const [count, setCount] = useState<number>(5);
  const [message, setMessage] = useState<string | null>(null);
  const [shortOffer, setShortOffer] = useState<{ available: number; filter: SessionFilter } | null>(null);

  const activeSession = session && !isComplete(session) ? session : null;
  const activeProgress = activeSession ? progress(activeSession) : null;

  const visibleDecks = useMemo(() => {
    // Взрослая колода видна только при включённом разделе.
    if (prefs.adultEnabled) return decks;
    return decks.filter((d) => !d.adult);
  }, [prefs.adultEnabled]);

  const toggleDeck = (id: string) => {
    setSelectedDecks((prev) => (prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]));
  };

  async function launch(filter: SessionFilter, wanted: number, allowShort: boolean): Promise<void> {
    setMessage(null);
    const outcome = startSession(filter, wanted, prefs, meta);
    if (!outcome.session) {
      if (outcome.totalEligible === 0) {
        setMessage(
          'Подходящих карточек нет: так бывает, если часть тем скрыта или выключен взрослый раздел. Измените фильтры или уберите скрытия в «Темы» и «Настройках». Мы не ослабляем ограничения автоматически.',
        );
      } else {
        setMessage(`Не хватает новых карточек: доступно ${outcome.totalEligible}.`);
      }
      return;
    }
    if (outcome.shortfall > 0 && !allowShort && !prefs.allowRepeats) {
      setShortOffer({ available: outcome.session.queue.length, filter });
      return;
    }
    const ok = await setSession(outcome.session);
    if (!ok) {
      setMessage('Сессия началась, но сохранить её не удалось: после перезагрузки она не восстановится.');
    } else if (outcome.shortfall > 0) {
      setMessage(`Получилась короткая сессия: ${outcome.session.queue.length} из ${wanted}.`);
    }
    goSession();
  }

  const quickStart = () => {
    const preset = PRESETS[0];
    if (!preset) return;
    void launch({ ...preset.filter }, preset.count, true);
  };

  return (
    <div className={styles.screen}>
      <h1 className={styles.title}>Ближе</h1>
      <p className={styles.subtitle}>
        Карточки для разговора вдвоём: 10–20 минут, один телефон, без регистрации и анкет.
      </p>
      {!offlineReady ? (
        <p className={styles.notice}>Офлайн будет готов после первой полной загрузки.</p>
      ) : (
        <p className={styles.notice}>Офлайн готов: начатый разговор можно закончить без интернета.</p>
      )}

      <div className={styles.section}>
        <Button variant="primary" data-testid="home-start-quick" onClick={quickStart}>
          Начать разговор
        </Button>
        <p className={styles.notice}>Быстрый старт: «Лёгкий вечер», 5 карточек, сразу первая карточка.</p>
        {activeSession && activeProgress ? (
          <Button variant="secondary" data-testid="home-continue" onClick={goSession}>
            Продолжить ({activeProgress.current}/{activeProgress.total})
          </Button>
        ) : null}
      </div>

      {message ? (
        <p role="status" className={styles.notice}>
          {message}
        </p>
      ) : null}

      <section className={styles.section} aria-label="Готовые подборки">
        <h2 className={styles.sectionTitle}>Готовые подборки</h2>
        {PRESETS.map((preset) => {
          const locked = preset.adult && !prefs.adultEnabled;
          return (
            <button
              key={preset.id}
              type="button"
              data-testid={`home-preset-${preset.id}`}
              className={locked ? `${styles.preset} ${styles.locked}` : styles.preset}
              disabled={locked}
              aria-disabled={locked}
              title={locked ? 'Доступно после включения взрослого раздела' : preset.description}
              onClick={() => void launch({ ...preset.filter }, preset.count, false)}
            >
              <span className={styles.presetName}>
                {preset.title} · {preset.count}
              </span>
              <span className={styles.presetDesc}>
                {locked ? 'О близости и границах. Доступно после включения взрослого раздела.' : preset.description}
              </span>
            </button>
          );
        })}
      </section>

      <section className={styles.section} aria-label="Своя сессия">
        <h2 className={styles.sectionTitle}>Своя сессия</h2>
        <div className={styles.row} role="group" aria-label="Темы">
          {visibleDecks.map((deck) => (
            <Chip
              key={deck.id}
              selected={selectedDecks.includes(deck.id)}
              onClick={() => toggleDeck(deck.id)}
              testId={`home-deck-${deck.id}`}
            >
              {deck.title}
            </Chip>
          ))}
        </div>
        <p className={styles.notice}>Пустой выбор тем означает «все темы».</p>
        <div className={styles.row} role="group" aria-label="Максимальная глубина">
          {(
            [
              ['light', 'Легко'],
              ['personal', 'Лично'],
              ['deep', 'Глубоко'],
            ] as Array<[Depth, string]>
          ).map(([depth, label]) => (
            <Chip
              key={depth}
              selected={maxDepth === depth}
              onClick={() => setMaxDepth(depth)}
              testId={`home-depth-${depth}`}
            >
              {label}
            </Chip>
          ))}
        </div>
        <div className={styles.row} role="group" aria-label="Длина подборки">
          {COUNTS.map((c) => (
            <Chip key={c} selected={count === c} onClick={() => setCount(c)} testId={`home-count-${c}`}>
              {c} карточек
            </Chip>
          ))}
        </div>
        <Button
          variant="secondary"
          data-testid="home-custom-start"
          onClick={() =>
            void launch(
              {
                deckIds: selectedDecks,
                maxDepth,
                includeAdult: prefs.adultEnabled,
              },
              count,
              false,
            )
          }
        >
          Начать свою сессию
        </Button>
      </section>

      <Dialog
        open={shortOffer !== null}
        title="Не хватает новых карточек"
        description={
          shortOffer
            ? `Новых подходящих карточек: ${shortOffer.available}. Начать короткую сессию или разрешить повторы в «Настройках»?`
            : undefined
        }
        confirmText="Начать короткую"
        cancelText="Выбрать другую"
        onConfirm={() => {
          const offer = shortOffer;
          setShortOffer(null);
          if (offer) void launch(offer.filter, offer.available, true);
        }}
        onCancel={() => setShortOffer(null)}
      />

      {prefs.hiddenDeckIds.length === 0 && prefs.hiddenCardIds.length === 0 ? null : (
        <EmptyState
          title="Часть библиотеки скрыта"
          description="Скрытые темы и карточки не попадают в подборки, поиск и восстановление сессии."
        />
      )}
    </div>
  );
}
