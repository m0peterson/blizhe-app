import { useState } from 'react';
import { cardById, deckById } from '../../modules/content';
import type { Card } from '../../modules/content';
import type { Preferences } from '../../modules/preferences';
import type { NoteKind } from '../../modules/saved';
import { NOTE_KIND_LABELS, addNote, deleteNote, notesByKind, toggleDeferred, toggleFavorite, toggleNoteDone, updateNote } from '../../modules/saved';
import { useStore } from '../store';
import { Button, Dialog, EmptyState, TextField } from '../../shared/ui';
import styles from './screens.module.css';

const KINDS: NoteKind[] = ['learned', 'agreement', 'idea'];

function randomId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `n-${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
}

/** Карточка видна в «Нашем», если прошла те же фильтры, что остальные входы. */
function isOurCardVisible(card: Card, prefs: Preferences): boolean {
  if (prefs.hiddenCardIds.includes(card.id)) return false;
  if (prefs.hiddenDeckIds.includes(card.deckId)) return false;
  if (!prefs.adultEnabled && card.adult) return false;
  if (prefs.adultEnabled && prefs.intimacyLevel === 'soft' && card.adult && card.intimacyLevel !== 'soft')
    return false;
  return true;
}

export function OurScreen() {
  const { prefs, saved, updateSaved } = useStore();
  const [kind, setKind] = useState<NoteKind>('learned');
  const [text, setText] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Фильтры действуют и здесь: скрытые темы/карточки и взрослые без доступа не показываются.
  const visibleFavorites = saved.favorites
    .map((id) => cardById.get(id))
    .filter((c): c is Card => c !== undefined)
    .filter((c) => isOurCardVisible(c, prefs));

  const visibleDeferred = saved.deferred
    .map((id) => cardById.get(id))
    .filter((c): c is Card => c !== undefined)
    .filter((c) => isOurCardVisible(c, prefs));

  const create = async () => {
    const value = text.trim();
    if (!value) return;
    await updateSaved(addNote(saved, { kind, text: value, cardId: null }, Date.now(), randomId()));
    setText('');
  };

  return (
    <div className={styles.screen}>
      <h1 className={styles.title}>Наше</h1>
      <p className={styles.subtitle}>
        Общий список для этого устройства, а не секретный дневник. Всё, что записано, видно тому, кто держит
        телефон.
      </p>

      <section className={styles.section} aria-label="Новая заметка">
        <h2 className={styles.sectionTitle}>Новая заметка</h2>
        <div className={styles.row} role="group" aria-label="Вид заметки">
          {KINDS.map((k) => (
            <button
              key={k}
              type="button"
              data-testid={`our-kind-${k}`}
              aria-pressed={kind === k}
              className={styles.preset}
              onClick={() => setKind(k)}
            >
              <span className={styles.presetName}>{NOTE_KIND_LABELS[k]}</span>
            </button>
          ))}
        </div>
        <TextField
          label="Текст"
          value={text}
          onChange={setText}
          placeholder="Можно без карточки: что узнали, о чём договорились, идея подарка…"
          multiline
          testId="our-note-text"
        />
        <Button variant="primary" data-testid="our-note-add" onClick={() => void create()} disabled={!text.trim()}>
          Добавить
        </Button>
      </section>

      {KINDS.map((k) => {
        const notes = notesByKind(saved, k);
        return (
          <section key={k} className={styles.section} aria-label={NOTE_KIND_LABELS[k]}>
            <h2 className={styles.sectionTitle}>{NOTE_KIND_LABELS[k]} ({notes.length})</h2>
            {notes.length === 0 ? (
              <p className={styles.notice}>Пока пусто.</p>
            ) : (
              notes.map((note) => {
                const linked = note.cardId ? cardById.get(note.cardId) : undefined;
                const isEditing = editingId === note.id;
                return (
                  <article key={note.id} data-testid={`our-note-${note.id}`}>
                    {isEditing ? (
                      <>
                        <TextField label="Редактирование" value={editingText} onChange={setEditingText} multiline testId={`our-edit-${note.id}`} />
                        <div className={styles.row}>
                          <Button
                            variant="primary"
                            onClick={() => {
                              void updateSaved(updateNote(saved, note.id, editingText, Date.now()));
                              setEditingId(null);
                            }}
                          >
                            Сохранить
                          </Button>
                          <Button variant="ghost" onClick={() => setEditingId(null)}>
                            Отмена
                          </Button>
                        </div>
                      </>
                    ) : (
                      <>
                        <p>{note.text}</p>
                        {linked && isOurCardVisible(linked, prefs) ? (
                          <p className={styles.notice}>
                            К карточке: {deckById.get(linked.deckId)?.title} — {linked.prompt.slice(0, 80)}…
                          </p>
                        ) : null}
                        <div className={styles.row}>
                          {note.kind === 'agreement' ? (
                            <Button
                              variant="ghost"
                              data-testid={`our-note-done-${note.id}`}
                              aria-pressed={note.done}
                              onClick={() => void updateSaved(toggleNoteDone(saved, note.id, Date.now()))}
                            >
                              {note.done ? 'Выполнено ✓' : 'Отметить выполненной'}
                            </Button>
                          ) : null}
                          <Button
                            variant="ghost"
                            onClick={() => {
                              setEditingId(note.id);
                              setEditingText(note.text);
                            }}
                          >
                            Редактировать
                          </Button>
                          <Button variant="ghost" onClick={() => setDeleteId(note.id)}>
                            Удалить
                          </Button>
                        </div>
                      </>
                    )}
                  </article>
                );
              })
            )}
          </section>
        );
      })}

      <section className={styles.section} aria-label="Избранное">
        <h2 className={styles.sectionTitle}>Избранное ({visibleFavorites.length})</h2>
        {visibleFavorites.length === 0 ? (
          <EmptyState title="Пока нет избранного" description="Отмечайте карточки звёздочкой в разговоре или в «Темы»." />
        ) : (
          visibleFavorites.map((card) => (
            <article key={card.id} data-testid={`our-fav-${card.id}`}>
              <p>{card.prompt}</p>
              <p className={styles.notice}>{deckById.get(card.deckId)?.title}</p>
              <div className={styles.row}>
                <Button variant="ghost" onClick={() => void updateSaved(toggleFavorite(saved, card.id))}>
                  Убрать
                </Button>
              </div>
            </article>
          ))
        )}
      </section>

      <section className={styles.section} aria-label="Обсудить позже">
        <h2 className={styles.sectionTitle}>Обсудить позже ({visibleDeferred.length})</h2>
        {visibleDeferred.length === 0 ? (
          <EmptyState title="Список пуст" description="Откладывайте карточки, чтобы вернуться к ним в удобный момент." />
        ) : (
          visibleDeferred.map((card) => (
            <article key={card.id} data-testid={`our-deferred-${card.id}`}>
              <p>{card.prompt}</p>
              <p className={styles.notice}>{deckById.get(card.deckId)?.title}</p>
              <div className={styles.row}>
                <Button variant="ghost" onClick={() => void updateSaved(toggleDeferred(saved, card.id))}>
                  Убрать
                </Button>
              </div>
            </article>
          ))
        )}
      </section>

      <Dialog
        open={deleteId !== null}
        title="Удалить заметку?"
        description="Это действие нельзя отменить."
        confirmText="Удалить"
        danger
        onConfirm={() => {
          if (deleteId) void updateSaved(deleteNote(saved, deleteId));
          setDeleteId(null);
        }}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}
