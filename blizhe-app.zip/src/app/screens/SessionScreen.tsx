import { useEffect, useRef, useState } from 'react';
import { cardById, deckById } from '../../modules/content';
import type { NoteKind } from '../../modules/saved';
import { addNote, toggleDeferred, toggleFavorite } from '../../modules/saved';
import { advance, currentCard, goBack, isComplete, progress, responderFor } from '../../modules/session';
import type { AdvanceAction } from '../../modules/session';
import { useStore } from '../store';
import { Button, CardView, Dialog, ProgressBar, TextField } from '../../shared/ui';
import styles from './screens.module.css';
import sessionStyles from './SessionScreen.module.css';

interface SessionScreenProps {
  goFinish: () => void;
  goHome: () => void;
}

const KIND_OPTIONS: Array<{ kind: NoteKind; label: string }> = [
  { kind: 'learned', label: 'Узнали друг о друге' },
  { kind: 'agreement', label: 'Договорились' },
  { kind: 'idea', label: 'Идея подарка или желания' },
];

const CLICK_LOCK_MS = 400;

export function SessionScreen({ goFinish, goHome }: SessionScreenProps) {
  const { prefs, saved, session, meta, setSession, updateSaved, updateMeta } = useStore();
  const [ownAnswer, setOwnAnswer] = useState('');
  const [noteOpen, setNoteOpen] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [noteKind, setNoteKind] = useState<NoteKind>('learned');
  const [finishOpen, setFinishOpen] = useState(false);
  const lastActionAtRef = useRef(0);

  const card = session ? currentCard(session) : null;
  const done = !session || isComplete(session);
  const prog = session ? progress(session) : { current: 0, total: 0 };
  const responder = session ? responderFor(session) : 'a';
  const responderName =
    responder === 'a' ? prefs.nameA.trim() || 'Первый участник' : prefs.nameB.trim() || 'Второй участник';

  // Локальная запись seen при показе. Ошибка сохранения не блокирует разговор.
  useEffect(() => {
    if (!card) return;
    setOwnAnswer('');
    if (meta.seenCardIds.includes(card.id)) return;
    void updateMeta({ ...meta, seenCardIds: [...meta.seenCardIds, card.id] });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [card?.id]);

  useEffect(() => {
    if (done) goFinish();
  }, [done, goFinish]);

  if (!session || !card) {
    return (
      <div className={styles.screen}>
        <h1 className={styles.title}>Разговор</h1>
        <p className={styles.notice}>Сессия пуста или уже завершена.</p>
        <Button variant="secondary" onClick={goHome}>
          На главную
        </Button>
      </div>
    );
  }

  // Лок от случайного двойного тапа: любое действие вперёд/назад не чаще раза в 400 мс.
  const locked = () => {
    const now = Date.now();
    if (now - lastActionAtRef.current < CLICK_LOCK_MS) return true;
    lastActionAtRef.current = now;
    return false;
  };

  const doAdvance = (action: AdvanceAction) => {
    if (!card || locked()) return;
    const next = advance(session, action, Date.now());
    void setSession(next);
  };

  const doBack = () => {
    if (!session || locked()) return;
    const next = goBack(session, Date.now());
    void setSession(next);
  };

  const isFavorite = saved.favorites.includes(card.id);
  const isDeferred = saved.deferred.includes(card.id);

  const saveThought = () => {
    const text = noteText.trim();
    if (!text) return;
    const id = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `n-${Date.now()}`;
    const next = addNote(saved, { kind: noteKind, text, cardId: card.id }, Date.now(), id);
    void updateSaved(next);
    setNoteText('');
    setNoteOpen(false);
  };

  return (
    <div className={styles.screen}>
      <ProgressBar current={prog.current} total={prog.total} testId="session-progress" />
      <p className={sessionStyles.turn} data-testid="session-turn">
        Сейчас отвечает: {responderName}
      </p>

      <CardView
        card={card}
        deckTitle={deckById.get(card.deckId)?.title ?? card.deckId}
        promptTestId="session-card-prompt"
      />

      {card.type === 'choice' ? (
        <div className={sessionStyles.ownAnswer}>
          <TextField
            label="Свой ответ"
            value={ownAnswer}
            onChange={setOwnAnswer}
            placeholder="Можно ответить вслух своими словами, писать необязательно"
            testId="session-own-answer"
            hint="Устные ответы никуда не записываются."
          />
        </div>
      ) : null}

      <div className={sessionStyles.actions}>
        <Button variant="primary" data-testid="session-action-discussed" onClick={() => doAdvance('discussed')}>
          Обсудили
        </Button>
        <div className={sessionStyles.secondaryRow}>
          <Button variant="secondary" data-testid="session-action-skip" onClick={() => doAdvance('skipped')}>
            Пропустить
          </Button>
          <Button variant="ghost" data-testid="session-action-back" onClick={doBack} disabled={session.index === 0}>
            Назад
          </Button>
        </div>
        <div className={sessionStyles.secondaryRow}>
          <Button
            variant="ghost"
            data-testid="session-action-favorite"
            onClick={() => void updateSaved(toggleFavorite(saved, card.id))}
            aria-pressed={isFavorite}
          >
            {isFavorite ? '★ В избранном' : '☆ В избранное'}
          </Button>
          <Button
            variant="ghost"
            data-testid="session-action-defer"
            onClick={() => void updateSaved(toggleDeferred(saved, card.id))}
            aria-pressed={isDeferred}
          >
            {isDeferred ? 'Отложена' : 'Обсудить позже'}
          </Button>
        </div>
        <div className={sessionStyles.secondaryRow}>
          <Button variant="ghost" data-testid="session-action-save-thought" onClick={() => setNoteOpen(true)}>
            Сохранить мысль
          </Button>
          <Button variant="ghost" data-testid="session-action-finish" onClick={() => setFinishOpen(true)}>
            Закончить
          </Button>
        </div>
      </div>

      <p className={styles.notice}>Пропуск — не ответ. «Назад» возвращает к карточке, повторное решение учитывается.</p>

      <Dialog
        open={noteOpen}
        title="Сохранить мысль"
        description={`К карточке «${cardById.get(card.id)?.prompt.slice(0, 60) ?? card.id}…». Сохраняется только то, что вы напишете.`}
        confirmText="Сохранить"
        onConfirm={saveThought}
        onCancel={() => setNoteOpen(false)}
      >
        <div className={sessionStyles.kindRow} role="group" aria-label="Вид заметки">
          {KIND_OPTIONS.map((o) => (
            <button
              key={o.kind}
              type="button"
              aria-pressed={noteKind === o.kind}
              className={noteKind === o.kind ? `${sessionStyles.kind} ${sessionStyles.kindActive}` : sessionStyles.kind}
              onClick={() => setNoteKind(o.kind)}
            >
              {o.label}
            </button>
          ))}
        </div>
        <TextField
          label="Мысль"
          value={noteText}
          onChange={setNoteText}
          placeholder="Одним-двумя предложениями"
          multiline
          testId="session-note-text"
        />
      </Dialog>

      <Dialog
        open={finishOpen}
        title="Закончить разговор?"
        description="Очерёдность и позиция сохранятся. Финал предложит необязательно сохранить один вывод."
        confirmText="Закончить"
        onConfirm={() => {
          setFinishOpen(false);
          goFinish();
        }}
        onCancel={() => setFinishOpen(false)}
      />
    </div>
  );
}
