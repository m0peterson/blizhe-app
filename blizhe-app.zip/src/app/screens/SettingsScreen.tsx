import { useEffect, useState } from 'react';
import { setAdultMode, setAllowRepeats, setNames } from '../../modules/preferences';
import { useStore } from '../store';
import { applyPwaUpdate } from '../../infrastructure/pwa/register';
import { Button, Dialog, TextField, Toggle } from '../../shared/ui';
import styles from './screens.module.css';

interface SettingsScreenProps {
  offlineReady: boolean;
  updateAvailable: boolean;
}

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
};

export function SettingsScreen({ offlineReady, updateAvailable }: SettingsScreenProps) {
  const { prefs, storageMode, updatePrefs, clearAll } = useStore();
  const [adultDialog, setAdultDialog] = useState(false);
  const [confirm18, setConfirm18] = useState(false);
  const [intimacy, setIntimacy] = useState<'soft' | 'frank' | null>(prefs.intimacyLevel);
  const [nameA, setNameA] = useState(prefs.nameA);
  const [nameB, setNameB] = useState(prefs.nameB);
  const [wipeOpen, setWipeOpen] = useState(false);
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  useEffect(() => {
    setIntimacy(prefs.intimacyLevel);
    setNameA(prefs.nameA);
    setNameB(prefs.nameB);
  }, [prefs.intimacyLevel, prefs.nameA, prefs.nameB]);

  const toggleAdult = (next: boolean) => {
    if (next) {
      setConfirm18(false);
      setIntimacy(prefs.intimacyLevel);
      setAdultDialog(true);
      return;
    }
    // Выключение убирает взрослые вопросы и из текущей сессии (через store).
    void updatePrefs(setAdultMode(prefs, false, null));
  };

  const confirmAdult = () => {
    if (!confirm18 || intimacy === null) return;
    void updatePrefs(setAdultMode(prefs, true, intimacy));
    setAdultDialog(false);
  };

  return (
    <div className={styles.screen}>
      <h1 className={styles.title}>Настройки</h1>

      <section className={styles.section} aria-label="Взрослый раздел">
        <h2 className={styles.sectionTitle}>Взрослый раздел</h2>
        <Toggle
          checked={prefs.adultEnabled}
          onChange={toggleAdult}
          label="Взрослый контент"
          description={
            prefs.adultEnabled
              ? `Включён: ${prefs.intimacyLevel === 'soft' ? 'Мягко' : 'Откровенно'}`
              : 'Выключен. Включение требует 18+ и выбора откровенности.'
          }
          testId="settings-adult-toggle"
        />
        <p className={styles.notice}>
          На общем телефоне это настройка пары, а не техническое доказательство согласия каждого человека.
          Выключение убирает такие вопросы из подборок, поиска, избранного и текущей сессии.
        </p>
      </section>

      <section className={styles.section} aria-label="Имена">
        <h2 className={styles.sectionTitle}>Имена (необязательно)</h2>
        <TextField label="Первый участник" value={nameA} onChange={setNameA} placeholder="Имя" testId="settings-name-a" />
        <TextField label="Второй участник" value={nameB} onChange={setNameB} placeholder="Имя" testId="settings-name-b" />
        <Button
          variant="secondary"
          data-testid="settings-names-save"
          onClick={() => void updatePrefs(setNames(prefs, nameA, nameB))}
        >
          Сохранить имена
        </Button>
      </section>

      <section className={styles.section} aria-label="Повторы">
        <h2 className={styles.sectionTitle}>Повторы</h2>
        <Toggle
          checked={prefs.allowRepeats}
          onChange={(next) => void updatePrefs(setAllowRepeats(prefs, next))}
          label="Разрешить повторы"
          description="Когда новых карточек не хватает, брать уже показанные. По умолчанию выключено."
          testId="settings-repeats-toggle"
        />
      </section>

      <section className={styles.section} aria-label="Данные">
        <h2 className={styles.sectionTitle}>Данные</h2>
        <p className={styles.notice}>
          Данные находятся в этом браузере, не синхронизируются и могут исчезнуть при очистке браузера. Локальное
          хранение не означает шифрование: человек с доступом к устройству увидит записи.
        </p>
        <p className={styles.notice}>
          Хранилище: {storageMode === 'memory' ? 'временный режим (не сохраняется)' : 'в этом браузере (IndexedDB)'}.
        </p>
        <Button variant="danger" data-testid="settings-wipe" onClick={() => setWipeOpen(true)}>
          Удалить все мои данные
        </Button>
      </section>

      <section className={styles.section} aria-label="Приложение">
        <h2 className={styles.sectionTitle}>Приложение</h2>
        <p className={styles.notice} data-testid="settings-offline-status">
          Офлайн: {offlineReady ? 'готов' : 'готовится (откройте приложение онлайн один раз)'}
        </p>
        <p className={styles.notice} data-testid="settings-update-status">
          Обновление: {updateAvailable ? 'доступно — применить можно ниже' : 'у вас последняя версия'}
        </p>
        {updateAvailable ? (
          <Button
            variant="secondary"
            data-testid="settings-apply-update"
            onClick={() => {
              void applyPwaUpdate().then(() => window.location.reload());
            }}
          >
            Применить обновление
          </Button>
        ) : null}
        {installEvent ? (
          <Button
            variant="secondary"
            data-testid="settings-install"
            onClick={() => {
              void installEvent.prompt();
              setInstallEvent(null);
            }}
          >
            Установить на домашний экран
          </Button>
        ) : (
          <p className={styles.notice}>Установка на домашний экран доступна через меню браузера, там где её поддерживает браузер.</p>
        )}
      </section>

      <Dialog
        open={adultDialog}
        title="Взрослый раздел — 18+"
        description="Подтвердите, что обоим участникам есть 18 лет, и выберите подходящую обоим откровенность. Глубокий разговор не обязан быть откровенным: это независимые настройки."
        confirmText="Включить"
        onConfirm={confirmAdult}
        onCancel={() => setAdultDialog(false)}
      >
        <Toggle
          checked={confirm18}
          onChange={setConfirm18}
          label="Нам обоим есть 18 лет"
          testId="settings-adult-18"
        />
        <div className={styles.row} role="group" aria-label="Откровенность">
          <button
            type="button"
            data-testid="settings-intimacy-soft"
            aria-pressed={intimacy === 'soft'}
            className={styles.preset}
            onClick={() => setIntimacy('soft')}
          >
            <span className={styles.presetName}>Мягко</span>
            <span className={styles.presetDesc}>Нежно и бережно, без explicit-деталей.</span>
          </button>
          <button
            type="button"
            data-testid="settings-intimacy-frank"
            aria-pressed={intimacy === 'frank'}
            className={styles.preset}
            onClick={() => setIntimacy('frank')}
          >
            <span className={styles.presetName}>Откровенно</span>
            <span className={styles.presetDesc}>Прямой разговор о желаниях и границах.</span>
          </button>
        </div>
        {!confirm18 || intimacy === null ? (
          <p className={styles.notice}>Нужно подтверждение 18+ и выбор откровенности.</p>
        ) : null}
      </Dialog>

      <Dialog
        open={wipeOpen}
        title="Удалить все мои данные?"
        description="Очистим записи, историю, избранное, скрытия, настройки и активную сессию. Взрослый раздел вернётся в выключенное состояние. Встроенная библиотека карточек останется."
        confirmText="Удалить всё"
        danger
        onConfirm={() => {
          setWipeOpen(false);
          void clearAll();
        }}
        onCancel={() => setWipeOpen(false)}
      />
    </div>
  );
}
