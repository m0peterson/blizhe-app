import { useMemo, useState } from 'react';
import { cardById, cards, deckById, decks, searchCards } from '../../modules/content';
import type { Depth } from '../../modules/content';
import { hideCard, hideDeck, unhideCard, unhideDeck } from '../../modules/preferences';
import { toggleDeferred, toggleFavorite } from '../../modules/saved';
import { useStore } from '../store';
import { Button, Chip, EmptyState, TextField } from '../../shared/ui';
import styles from './screens.module.css';

function statusLabel(cardId: string, states: Record<string, string>, seen: string[]): string {
  const state = states[cardId];
  if (state === 'discussed') return 'обсуждена';
  if (state === 'skipped') return 'пропущена';
  if (state === 'deferred') return 'отложена';
  if (state === 'shown') return 'показана';
  if (seen.includes(cardId)) return 'показана';
  return 'новая';
}

export function TopicsScreen() {
  const { prefs, saved, session, meta, updatePrefs, updateSaved } = useStore();
  const [query, setQuery] = useState('');
  const [depth, setDepth] = useState<Depth | 'all'>('all');
  const [deckFilter, setDeckFilter] = useState<string | null>(null);

  const states = session?.states ?? {};

  const eligible = useMemo(() => {
    // Фильтры действуют везде: скрытые и взрослые без доступа не показываются.
    let list = cards.filter((c) => !prefs.hiddenCardIds.includes(c.id));
    list = list.filter((c) => !prefs.hiddenDeckIds.includes(c.deckId));
    if (!prefs.adultEnabled) list = list.filter((c) => !c.adult);
    else if (prefs.intimacyLevel === 'soft') list = list.filter((c) => !c.adult || c.intimacyLevel === 'soft');
    if (depth !== 'all') {
      const rank: Record<Depth, number> = { light: 0, personal: 1, deep: 2 };
      list = list.filter((c) => rank[c.depth] <= rank[depth]);
    }
    if (deckFilter) list = list.filter((c) => c.deckId === deckFilter);
    return searchCards(list, deckById, query);
  }, [prefs, depth, deckFilter, query]);

  const visibleDecks = useMemo(() => {
    const base = prefs.adultEnabled ? decks : decks.filter((d) => !d.adult);
    return base.filter((d) => !prefs.hiddenDeckIds.includes(d.id));
  }, [prefs]);

  const hiddenDecks = decks.filter((d) => prefs.hiddenDeckIds.includes(d.id));

  return (
    <div className={styles.screen}>
      <h1 className={styles.title}>Темы</h1>
      <p className={styles.subtitle}>Библиотека тем с описанием, фильтрами и поиском по текстам и тегам.</p>

      <TextField
        label="Поиск"
        value={query}
        onChange={setQuery}
        placeholder="Текст или тег: поддержка, деньги, свидание…"
        testId="topics-search"
      />

      <div className={styles.row} role="group" aria-label="Фильтр по глубине">
        <Chip selected={depth === 'all'} onClick={() => setDepth('all')} testId="topics-depth-all">
          Все глубины
        </Chip>
        <Chip selected={depth === 'light'} onClick={() => setDepth('light')} testId="topics-depth-light">
          Легко
        </Chip>
        <Chip selected={depth === 'personal'} onClick={() => setDepth('personal')} testId="topics-depth-personal">
          Лично
        </Chip>
        <Chip selected={depth === 'deep'} onClick={() => setDepth('deep')} testId="topics-depth-deep">
          Глубоко
        </Chip>
      </div>

      <div className={styles.row} role="group" aria-label="Фильтр по теме">
        <Chip selected={deckFilter === null} onClick={() => setDeckFilter(null)}>
          Все темы
        </Chip>
        {visibleDecks.map((deck) => (
          <Chip key={deck.id} selected={deckFilter === deck.id} onClick={() => setDeckFilter(deck.id)} testId={`topics-deck-${deck.id}`}>
            {deck.title}
          </Chip>
        ))}
      </div>

      {eligible.length === 0 ? (
        <EmptyState
          title="Ничего не подошло"
          description="Причина — фильтры, поиск или скрытия. Измените запрос, глубину или уберите скрытые темы ниже. Мы не включаем взрослый контент автоматически."
        />
      ) : (
        <p className={styles.notice} role="status">
          Найдено: {eligible.length}
        </p>
      )}

      {visibleDecks
        .filter((deck) => !deckFilter || deck.id === deckFilter)
        .map((deck) => {
          const deckCards = eligible.filter((c) => c.deckId === deck.id);
          if (deckCards.length === 0) return null;
          return (
            <section key={deck.id} className={styles.section} aria-label={deck.title}>
              <h2 className={styles.sectionTitle}>{deck.title}</h2>
              <p className={styles.notice}>{deck.description}</p>
              <Button variant="ghost" onClick={() => void updatePrefs(hideDeck(prefs, deck.id))} data-testid={`topics-hide-deck-${deck.id}`}>
                Скрыть тему
              </Button>
              {deckCards.map((card) => {
                const fav = saved.favorites.includes(card.id);
                const def = saved.deferred.includes(card.id);
                return (
                  <article key={card.id} className={styles.section} data-testid={`topics-card-${card.id}`}>
                    <p>{card.prompt}</p>
                    <p className={styles.notice}>
                      {card.depth === 'light' ? 'Легко' : card.depth === 'personal' ? 'Лично' : 'Глубоко'} ·{' '}
                      {statusLabel(card.id, states, meta.seenCardIds)}
                      {card.adult ? ` · ${card.intimacyLevel === 'soft' ? 'Мягко' : 'Откровенно'}` : ''}
                    </p>
                    <div className={styles.row}>
                      <Button
                        variant="ghost"
                        aria-pressed={fav}
                        data-testid={`topics-fav-${card.id}`}
                        onClick={() => void updateSaved(toggleFavorite(saved, card.id))}
                      >
                        {fav ? '★ В избранном' : 'В избранное'}
                      </Button>
                      <Button
                        variant="ghost"
                        aria-pressed={def}
                        data-testid={`topics-defer-${card.id}`}
                        onClick={() => void updateSaved(toggleDeferred(saved, card.id))}
                      >
                        {def ? 'Отложена' : 'Обсудить позже'}
                      </Button>
                      <Button
                        variant="ghost"
                        data-testid={`topics-hide-${card.id}`}
                        onClick={() => void updatePrefs(hideCard(prefs, card.id))}
                      >
                        Скрыть карточку
                      </Button>
                    </div>
                  </article>
                );
              })}
            </section>
          );
        })}

      {prefs.hiddenCardIds.length > 0 || hiddenDecks.length > 0 ? (
        <section className={styles.section} aria-label="Скрытое">
          <h2 className={styles.sectionTitle}>Скрытое</h2>
          {hiddenDecks.map((deck) => (
            <div key={deck.id} className={styles.row}>
              <span className={styles.notice}>Тема: {deck.title}</span>
              <Button variant="ghost" onClick={() => void updatePrefs(unhideDeck(prefs, deck.id))}>
                Показать
              </Button>
            </div>
          ))}
          {prefs.hiddenCardIds.map((id) => (
            <div key={id} className={styles.row}>
              <span className={styles.notice}>{cardById.get(id)?.prompt.slice(0, 80) ?? id}</span>
              <Button variant="ghost" onClick={() => void updatePrefs(unhideCard(prefs, id))}>
                Показать
              </Button>
            </div>
          ))}
        </section>
      ) : null}
    </div>
  );
}
