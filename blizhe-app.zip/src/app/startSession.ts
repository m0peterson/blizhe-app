import { cards, PRESETS } from '../modules/content';
import type { Preset } from '../modules/content';
import { buildQueue, createSession } from '../modules/session';
import type { SessionFilter, SessionState } from '../modules/session';
import type { Preferences } from '../modules/preferences';
import type { MetaState } from '../infrastructure/storage';

export interface StartOutcome {
  session: SessionState | null;
  totalEligible: number;
  shortfall: number;
  reason: 'ok' | 'short' | 'empty';
  repeatsUsed: boolean;
}

function randomId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `s-${Date.now()}-${Math.floor(Math.random() * 1_000_000)}`;
}

export function startSession(
  filter: SessionFilter,
  count: number,
  prefs: Preferences,
  meta: MetaState,
  rng: () => number = Math.random,
): StartOutcome {
  const result = buildQueue(
    cards,
    { prefs, filter },
    {
      count,
      preferUnseen: true,
      seenIds: meta.seenCardIds,
      allowRepeats: prefs.allowRepeats,
      rng,
    },
  );
  if (result.queue.length === 0) {
    return {
      session: null,
      totalEligible: result.totalEligible,
      shortfall: result.shortfall,
      reason: result.reason,
      repeatsUsed: result.repeatsUsed,
    };
  }
  // Первый отвечающий чередуется по числу показанных: детерминировано от seen.
  const firstResponder = meta.seenCardIds.length % 2 === 0 ? 'a' : 'b';
  const now = Date.now();
  const session = createSession(result.queue, filter, firstResponder, now, randomId());
  return {
    session,
    totalEligible: result.totalEligible,
    shortfall: result.shortfall,
    reason: result.reason,
    repeatsUsed: result.repeatsUsed,
  };
}

export function presetById(id: string): Preset | undefined {
  return PRESETS.find((p) => p.id === id);
}
