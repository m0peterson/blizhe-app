import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { CONTENT_VERSION } from '../modules/content';
import type { SessionState } from '../modules/session';
import { reapplyConstraints } from '../modules/session';
import { DEFAULT_PREFERENCES } from '../modules/preferences';
import type { Preferences } from '../modules/preferences';
import { EMPTY_SAVED } from '../modules/saved';
import type { SavedState } from '../modules/saved';
import {
  clearAllUserData,
  clearSession,
  createKvStore,
  loadMeta,
  loadPreferences,
  loadSaved,
  loadSession,
  saveMeta,
  savePreferences,
  saveSaved,
  saveSession,
} from '../infrastructure/storage';
import type { KvStore, MetaState } from '../infrastructure/storage';
import { EMPTY_META } from '../infrastructure/storage';

export interface StoreValue {
  ready: boolean;
  storageMode: 'indexeddb' | 'memory' | null;
  storageError: string | null;
  saveError: string | null;
  prefs: Preferences;
  saved: SavedState;
  session: SessionState | null;
  meta: MetaState;
  updatePrefs: (next: Preferences) => Promise<boolean>;
  updateSaved: (next: SavedState) => Promise<boolean>;
  setSession: (next: SessionState | null) => Promise<boolean>;
  updateMeta: (next: MetaState) => Promise<boolean>;
  clearAll: () => Promise<void>;
}

const StoreContext = createContext<StoreValue | null>(null);

export function useStore(): StoreValue {
  const value = useContext(StoreContext);
  if (!value) throw new Error('Store не инициализирован');
  return value;
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [kv, setKv] = useState<KvStore | null>(null);
  const [ready, setReady] = useState(false);
  const [storageMode, setStorageMode] = useState<'indexeddb' | 'memory' | null>(null);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [prefs, setPrefs] = useState<Preferences>({ ...DEFAULT_PREFERENCES });
  const [saved, setSaved] = useState<SavedState>({ ...EMPTY_SAVED, notes: [] });
  const [session, setSessionState] = useState<SessionState | null>(null);
  const [meta, setMeta] = useState<MetaState>({ ...EMPTY_META });

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const store = await createKvStore();
        if (cancelled) return;
        setKv(store);
        setStorageMode(store.mode);
        const [p, s, m, sess] = await Promise.all([
          loadPreferences(store).catch(() => ({ ...DEFAULT_PREFERENCES })),
          loadSaved(store).catch(() => ({ ...EMPTY_SAVED, notes: [] as SavedState['notes'] })),
          loadMeta(store).catch(() => ({ ...EMPTY_META })),
          loadSession(store).catch(() => null),
        ]);
        if (cancelled) return;
        // Контент мог обновиться: фиксируем версию, seen не трогаем.
        const nextMeta: MetaState =
          m.contentVersion === CONTENT_VERSION ? m : { ...m, contentVersion: CONTENT_VERSION };
        let nextSession = sess;
        if (sess) {
          // Новые ограничения сильнее сохранённой очереди.
          const reapplied = reapplyConstraints(sess, p, Date.now());
          nextSession = reapplied;
          if (reapplied.queue.length === 0) nextSession = null;
        }
        setPrefs(p);
        setSaved(s);
        setMeta(nextMeta);
        setSessionState(nextSession);
        if (nextMeta !== m) {
          await saveMeta(store, nextMeta).catch(() => undefined);
        }
        if (sess && nextSession !== sess) {
          if (nextSession) await saveSession(store, nextSession).catch(() => undefined);
          else await clearSession(store).catch(() => undefined);
        }
      } catch {
        if (!cancelled) setStorageError('Не удалось открыть хранилище. Работаем без сохранения.');
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const updatePrefs = useCallback(
    async (next: Preferences): Promise<boolean> => {
      setPrefs(next);
      if (!kv) {
        setSaveError('Хранилище ещё не готово: настройка применена только до перезагрузки.');
        return false;
      }
      try {
        await savePreferences(kv, next);
        // Ограничения могли усилиться: чистим активную сессию сразу.
        setSessionState((current) => {
          if (!current) return current;
          const reapplied = reapplyConstraints(current, next, Date.now());
          if (reapplied.queue.length === 0) {
            void clearSession(kv).catch(() => undefined);
            return null;
          }
          if (reapplied !== current) {
            void saveSession(kv, reapplied).catch(() => undefined);
          }
          return reapplied;
        });
        setSaveError(null);
        return true;
      } catch {
        setSaveError('Не удалось сохранить настройки.');
        return false;
      }
    },
    [kv],
  );

  const updateSaved = useCallback(
    async (next: SavedState): Promise<boolean> => {
      setSaved(next);
      if (!kv) {
        setSaveError('Хранилище ещё не готово: изменение применено только до перезагрузки.');
        return false;
      }
      try {
        await saveSaved(kv, next);
        setSaveError(null);
        return true;
      } catch {
        setSaveError('Не удалось сохранить. Изменение действует до перезагрузки.');
        return false;
      }
    },
    [kv],
  );

  const setSession = useCallback(
    async (next: SessionState | null): Promise<boolean> => {
      setSessionState(next);
      if (!kv) {
        setSaveError('Хранилище ещё не готово: сессия не сохранится после перезагрузки.');
        return false;
      }
      try {
        if (next) await saveSession(kv, next);
        else await clearSession(kv);
        setSaveError(null);
        return true;
      } catch {
        setSaveError('Не удалось сохранить сессию.');
        return false;
      }
    },
    [kv],
  );

  const updateMeta = useCallback(
    async (next: MetaState): Promise<boolean> => {
      setMeta(next);
      if (!kv) return false;
      try {
        await saveMeta(kv, next);
        return true;
      } catch {
        setSaveError('Не удалось сохранить прогресс.');
        return false;
      }
    },
    [kv],
  );

  const clearAll = useCallback(async () => {
    if (kv) {
      await clearAllUserData(kv).catch(() => undefined);
    }
    setPrefs({ ...DEFAULT_PREFERENCES });
    setSaved({ ...EMPTY_SAVED, notes: [] });
    setSessionState(null);
    setMeta({ ...EMPTY_META });
    setSaveError(null);
  }, [kv]);

  const value = useMemo<StoreValue>(
    () => ({
      ready,
      storageMode,
      storageError,
      saveError,
      prefs,
      saved,
      session,
      meta,
      updatePrefs,
      updateSaved,
      setSession,
      updateMeta,
      clearAll,
    }),
    [ready, storageMode, storageError, saveError, prefs, saved, session, meta, updatePrefs, updateSaved, setSession, updateMeta, clearAll],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}
