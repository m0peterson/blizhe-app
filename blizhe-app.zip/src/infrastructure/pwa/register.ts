/**
 * Регистрация service worker.
 * Обновление применяется только по действию пользователя,
 * страница никогда не перезагружается посреди сессии сама.
 */

export interface PwaCallbacks {
  onUpdateAvailable?: () => void;
  onReady?: () => void;
}

export function isPwaSupported(): boolean {
  return typeof navigator !== 'undefined' && 'serviceWorker' in navigator;
}

function emit(name: 'blizhe:pwa-update' | 'blizhe:pwa-ready'): void {
  window.dispatchEvent(new CustomEvent(name));
}

export async function registerPwa(callbacks: PwaCallbacks = {}): Promise<void> {
  if (!isPwaSupported()) return;
  // Ждём загрузку, чтобы не мешать первому рендеру.
  if (document.readyState === 'loading') {
    await new Promise<void>((resolve) => {
      window.addEventListener('DOMContentLoaded', () => resolve(), { once: true });
    });
  }
  try {
    const registration = await navigator.serviceWorker.register('./sw.js', { scope: './' });

    const watch = (worker: ServiceWorker | null) => {
      if (!worker) return;
      worker.addEventListener('statechange', () => {
        if (worker.state === 'installed' && navigator.serviceWorker.controller) {
          callbacks.onUpdateAvailable?.();
          emit('blizhe:pwa-update');
        }
      });
    };

    if (registration.waiting) {
      callbacks.onUpdateAvailable?.();
      emit('blizhe:pwa-update');
    }
    registration.addEventListener('updatefound', () => watch(registration.installing));

    await navigator.serviceWorker.ready;
    callbacks.onReady?.();
    emit('blizhe:pwa-ready');
  } catch {
    // Офлайн-кеш недоступен: приложение всё равно работает онлайн.
    return;
  }
}

/** Применить ожидающее обновление: вызывается только из UI по кнопке. */
export async function applyPwaUpdate(): Promise<void> {
  if (!isPwaSupported()) return;
  const registration = await navigator.serviceWorker.getRegistration('./');
  const waiting = registration?.waiting;
  if (waiting) {
    waiting.postMessage({ type: 'SKIP_WAITING' });
  }
}
