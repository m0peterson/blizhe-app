import type { KvStore } from './kv';
import { createMemoryKv } from './memoryKv';
import { DB_NAME, STORE_NAME, DATA_SCHEMA_VERSION } from './schema';

function idbAvailable(): boolean {
  return typeof indexedDB !== 'undefined';
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    try {
      const request = indexedDB.open(DB_NAME, DATA_SCHEMA_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'));
      request.onblocked = () => reject(new Error('IndexedDB blocked'));
    } catch (err) {
      reject(err instanceof Error ? err : new Error('IndexedDB unavailable'));
    }
  });
}

function tx<T>(db: IDBDatabase, mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    let result: T;
    let request: IDBRequest<T>;
    try {
      request = run(store);
    } catch (err) {
      reject(err instanceof Error ? err : new Error('IndexedDB request failed'));
      return;
    }
    request.onsuccess = () => {
      result = request.result;
    };
    request.onerror = () => reject(request.error ?? new Error('IndexedDB request failed'));
    transaction.oncomplete = () => resolve(result);
    transaction.onerror = () => reject(transaction.error ?? new Error('IndexedDB transaction failed'));
    transaction.onabort = () => reject(transaction.error ?? new Error('IndexedDB transaction aborted'));
  });
}

/**
 * Пытается открыть IndexedDB, при недоступности молча возвращает
 * in-memory реализацию. Вызывающий код обязан показать предупреждение,
 * что прогресс не сохранится.
 */
export async function createKvStore(): Promise<KvStore> {
  if (!idbAvailable()) return createMemoryKv();
  try {
    const db = await openDb();
    const store: KvStore = {
      mode: 'indexeddb',
      async get<T>(key: string): Promise<T | null> {
        try {
          const value = await tx<T | undefined>(db, 'readonly', (s) => s.get(key));
          return (value ?? null) as T | null;
        } catch {
          throw new Error('Не удалось прочитать данные');
        }
      },
      async set(key: string, value: unknown): Promise<void> {
        try {
          await tx(db, 'readwrite', (s) => s.put(value, key));
        } catch {
          throw new Error('Не удалось сохранить данные');
        }
      },
      async del(key: string): Promise<void> {
        try {
          await tx(db, 'readwrite', (s) => s.delete(key));
        } catch {
          throw new Error('Не удалось удалить данные');
        }
      },
      async clear(): Promise<void> {
        try {
          await tx(db, 'readwrite', (s) => s.clear());
        } catch {
          throw new Error('Не удалось очистить данные');
        }
      },
    };
    return store;
  } catch {
    return createMemoryKv();
  }
}
