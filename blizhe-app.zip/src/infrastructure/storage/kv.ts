/** Минимальный key-value интерфейс поверх IndexedDB с fallback в память. */

export type KvMode = 'indexeddb' | 'memory';

export interface KvStore {
  readonly mode: KvMode;
  get<T>(key: string): Promise<T | null>;
  set(key: string, value: unknown): Promise<void>;
  del(key: string): Promise<void>;
  clear(): Promise<void>;
}
