import type { KvStore } from './kv';

/** In-memory fallback: сессия живёт только до перезагрузки вкладки. */
export function createMemoryKv(): KvStore {
  const data = new Map<string, unknown>();
  return {
    mode: 'memory',
    async get<T>(key: string): Promise<T | null> {
      if (!data.has(key)) return null;
      return data.get(key) as T;
    },
    async set(key: string, value: unknown): Promise<void> {
      data.set(key, value);
    },
    async del(key: string): Promise<void> {
      data.delete(key);
    },
    async clear(): Promise<void> {
      data.clear();
    },
  };
}
