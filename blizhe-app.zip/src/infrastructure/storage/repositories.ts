import { CONTENT_VERSION } from '../../modules/content';
import type { SessionState } from '../../modules/session';
import { DEFAULT_PREFERENCES, USER_SCHEMA_VERSION } from '../../modules/preferences';
import type { Preferences } from '../../modules/preferences';
import { EMPTY_SAVED } from '../../modules/saved';
import type { SavedState } from '../../modules/saved';
import type { KvStore } from './kv';
import { KEYS } from './schema';

export interface MetaState {
  /** id показанных карточек, для preferUnseen при новых сессиях. */
  seenCardIds: string[];
  contentVersion: number;
}

export const EMPTY_META: MetaState = { seenCardIds: [], contentVersion: CONTENT_VERSION };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string') : [];
}

/** Миграция preferences: неизвестные поля отбрасываются, отсутствующие берутся из дефолта. */
export function migratePreferences(raw: unknown): Preferences {
  if (!isRecord(raw)) return { ...DEFAULT_PREFERENCES };
  return {
    schemaVersion: USER_SCHEMA_VERSION,
    adultEnabled: raw.adultEnabled === true,
    intimacyLevel: raw.intimacyLevel === 'soft' || raw.intimacyLevel === 'frank' ? raw.intimacyLevel : null,
    hiddenDeckIds: asStringArray(raw.hiddenDeckIds),
    hiddenCardIds: asStringArray(raw.hiddenCardIds),
    nameA: typeof raw.nameA === 'string' ? raw.nameA : '',
    nameB: typeof raw.nameB === 'string' ? raw.nameB : '',
    allowRepeats: raw.allowRepeats === true,
  };
}

/** Миграция saved: заметки, избранное и отложенное не теряются. */
export function migrateSaved(raw: unknown): SavedState {
  if (!isRecord(raw)) return { ...EMPTY_SAVED, notes: [] };
  const notesRaw = Array.isArray(raw.notes) ? raw.notes : [];
  const notes = notesRaw
    .filter(isRecord)
    .filter((n) => typeof n.id === 'string' && typeof n.text === 'string')
    .map((n) => ({
      id: n.id as string,
      kind: n.kind === 'agreement' || n.kind === 'idea' ? (n.kind as 'agreement' | 'idea') : ('learned' as const),
      text: n.text as string,
      cardId: typeof n.cardId === 'string' ? (n.cardId as string) : null,
      createdAt: typeof n.createdAt === 'number' ? (n.createdAt as number) : 0,
      updatedAt: typeof n.updatedAt === 'number' ? (n.updatedAt as number) : 0,
      done: n.done === true,
    }));
  return {
    schemaVersion: 1,
    favorites: asStringArray(raw.favorites),
    deferred: asStringArray(raw.deferred),
    notes,
  };
}

export function migrateMeta(raw: unknown): MetaState {
  if (!isRecord(raw)) return { ...EMPTY_META };
  return {
    seenCardIds: asStringArray(raw.seenCardIds),
    contentVersion: typeof raw.contentVersion === 'number' ? (raw.contentVersion as number) : CONTENT_VERSION,
  };
}

function isSessionState(raw: unknown): raw is SessionState {
  if (!isRecord(raw)) return false;
  return Array.isArray(raw.queue) && typeof raw.index === 'number' && typeof raw.finished === 'boolean';
}

export async function loadPreferences(store: KvStore): Promise<Preferences> {
  const raw = await store.get<unknown>(KEYS.preferences);
  if (raw === null) return { ...DEFAULT_PREFERENCES };
  const prefs = migratePreferences(raw);
  // Неконсистентное состояние (взрослый включён без откровенности) чинится в выключенное.
  if (prefs.adultEnabled && prefs.intimacyLevel === null) {
    return { ...prefs, adultEnabled: false };
  }
  return prefs;
}

export async function savePreferences(store: KvStore, prefs: Preferences): Promise<void> {
  await store.set(KEYS.preferences, prefs);
}

export async function loadSession(store: KvStore): Promise<SessionState | null> {
  const raw = await store.get<unknown>(KEYS.session);
  if (raw === null || !isSessionState(raw)) return null;
  return raw;
}

export async function saveSession(store: KvStore, session: SessionState): Promise<void> {
  await store.set(KEYS.session, session);
}

export async function clearSession(store: KvStore): Promise<void> {
  await store.del(KEYS.session);
}

export async function loadSaved(store: KvStore): Promise<SavedState> {
  const raw = await store.get<unknown>(KEYS.saved);
  if (raw === null) return { ...EMPTY_SAVED, notes: [] };
  return migrateSaved(raw);
}

export async function saveSaved(store: KvStore, saved: SavedState): Promise<void> {
  await store.set(KEYS.saved, saved);
}

export async function loadMeta(store: KvStore): Promise<MetaState> {
  const raw = await store.get<unknown>(KEYS.meta);
  if (raw === null) return { ...EMPTY_META };
  return migrateMeta(raw);
}

export async function saveMeta(store: KvStore, meta: MetaState): Promise<void> {
  await store.set(KEYS.meta, meta);
}

export async function markCardSeen(store: KvStore, cardId: string): Promise<MetaState> {
  const meta = await loadMeta(store);
  if (meta.seenCardIds.includes(cardId)) return meta;
  const next = { ...meta, seenCardIds: [...meta.seenCardIds, cardId] };
  await saveMeta(store, next);
  return next;
}

/** Полный сброс: записи, история, избранное, скрытия, настройки, активная сессия. */
export async function clearAllUserData(store: KvStore): Promise<void> {
  await store.del(KEYS.preferences);
  await store.del(KEYS.session);
  await store.del(KEYS.saved);
  await store.del(KEYS.meta);
}
