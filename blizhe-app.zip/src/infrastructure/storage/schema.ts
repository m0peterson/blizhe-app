/**
 * Версия схемы пользовательских данных. Отдельно от CONTENT_VERSION.
 * При повышении версии добавляется миграция в repositories.ts,
 * старые заметки при миграции не теряются.
 */
export const DATA_SCHEMA_VERSION = 1;
export const DB_NAME = 'blizhe';
export const STORE_NAME = 'kv';

export const KEYS = {
  preferences: 'blizhe:preferences:v1',
  session: 'blizhe:session:v1',
  saved: 'blizhe:saved:v1',
  meta: 'blizhe:meta:v1',
} as const;
