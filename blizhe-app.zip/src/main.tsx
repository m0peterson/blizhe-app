import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './styles/global.css';
import { App } from './app/App';
import { registerPwa } from './infrastructure/pwa/register';

const container = document.getElementById('root');
if (!container) {
  throw new Error('Не найден элемент #root');
}

createRoot(container).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// Обновления PWA никогда не перезагружают страницу сами: приложение
// показывает предложение обновиться и делает это только по действию пользователя.
void registerPwa();
