import type { Depth } from './types';
import type { SessionFilter } from '../session/types';

export interface Preset {
  id: string;
  title: string;
  description: string;
  /** Пресет требует включённого взрослого раздела. */
  adult: boolean;
  count: number;
  filter: SessionFilter;
}

const NON_ADULT_DECKS = [
  'znakomstvo',
  'byt',
  'obshchenie',
  'raznoglasiya',
  'zabota',
  'dengi',
  'podarki',
  'okruzhenie',
  'cennosti',
  'otdyh',
  'mechty',
];

function filterOf(deckIds: string[], maxDepth: Depth, includeAdult = false): SessionFilter {
  return { deckIds, maxDepth, includeAdult };
}

/** Пресеты хранят фильтры, а не копии текстов карточек. */
export const PRESETS: Preset[] = [
  {
    id: 'legkiy-vecher',
    title: 'Лёгкий вечер',
    description: 'Пять лёгких вопросов из разных тем: чтобы просто поговорить.',
    adult: false,
    count: 5,
    filter: filterOf(NON_ADULT_DECKS, 'light'),
  },
  {
    id: 'luchshe-ponyat',
    title: 'Лучше понять друг друга',
    description: 'О том, как вы думаете, чувствуете и видите друг друга.',
    adult: false,
    count: 10,
    filter: filterOf(['znakomstvo', 'obshchenie', 'cennosti', 'mechty'], 'personal'),
  },
  {
    id: 'byt-bez-nedomolvok',
    title: 'Быт без недомолвок',
    description: 'Дом, привычки и деньги: где рождается бытовое раздражение.',
    adult: false,
    count: 10,
    filter: filterOf(['byt', 'dengi'], 'personal'),
  },
  {
    id: 'podarki-i-zabota',
    title: 'Подарки и забота',
    description: 'Как вы показываете внимание и что для него важно.',
    adult: false,
    count: 5,
    filter: filterOf(['podarki', 'zabota'], 'personal'),
  },
  {
    id: 'blizost-i-zhelaniya',
    title: 'Близость и желания',
    description: 'О близости, желаниях и границах. Доступно после включения взрослого раздела.',
    adult: true,
    count: 5,
    filter: filterOf(['seks', 'zabota'], 'deep', true),
  },
];
