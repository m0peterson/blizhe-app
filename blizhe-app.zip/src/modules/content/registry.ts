import { parseDeckFile, validateRegistry } from './schema';
import type { Card, Deck, DeckFile } from './types';
import znakomstvo from './data/znakomstvo.json';
import byt from './data/byt.json';
import obshchenie from './data/obshchenie.json';
import raznoglasiya from './data/raznoglasiya.json';
import zabota from './data/zabota.json';
import seks from './data/seks.json';
import dengi from './data/dengi.json';
import podarki from './data/podarki.json';
import okruzhenie from './data/okruzhenie.json';
import cennosti from './data/cennosti.json';
import otdyh from './data/otdyh.json';
import mechty from './data/mechty.json';

/** Версия схемы контента. Версионируется отдельно от пользовательских данных. */
export const CONTENT_VERSION = 1;

const SOURCES: Array<{ source: string; raw: unknown }> = [
  { source: 'znakomstvo.json', raw: znakomstvo },
  { source: 'byt.json', raw: byt },
  { source: 'obshchenie.json', raw: obshchenie },
  { source: 'raznoglasiya.json', raw: raznoglasiya },
  { source: 'zabota.json', raw: zabota },
  { source: 'seks.json', raw: seks },
  { source: 'dengi.json', raw: dengi },
  { source: 'podarki.json', raw: podarki },
  { source: 'okruzhenie.json', raw: okruzhenie },
  { source: 'cennosti.json', raw: cennosti },
  { source: 'otdyh.json', raw: otdyh },
  { source: 'mechty.json', raw: mechty },
];

const parsed = SOURCES.map(({ source, raw }) => ({ source, result: parseDeckFile(raw, source) }));

const registryErrors = parsed.flatMap(({ result }) => result.errors);
registryErrors.push(...validateRegistry(parsed.map(({ result }) => result)));
if (registryErrors.length > 0) {
  // Ошибка схемы контента — ошибка сборки данных, а не пользовательский сценарий.
  throw new Error(`Контент не прошёл валидацию:\n${registryErrors.join('\n')}`);
}

export const deckFiles: DeckFile[] = parsed.map(({ result }) => ({
  deck: result.deck as Deck,
  cards: result.cards,
}));

export const decks: Deck[] = deckFiles.map((file) => file.deck);
export const cards: Card[] = deckFiles.flatMap((file) => file.cards);

export const deckById: Map<string, Deck> = new Map(decks.map((deck) => [deck.id, deck]));
export const cardById: Map<string, Card> = new Map(cards.map((card) => [card.id, card]));

export function cardsForDeck(deckId: string): Card[] {
  return cards.filter((card) => card.deckId === deckId);
}
