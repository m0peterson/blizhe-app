import type { Card, CardKind, Depth, Deck, IntimacyLevel } from './types';

const DEPTHS: readonly Depth[] = ['light', 'personal', 'deep'];
const KINDS: readonly CardKind[] = ['open', 'choice', 'action'];
const INTIMACY: readonly IntimacyLevel[] = ['soft', 'frank'];

export interface ParseResult {
  deck: Deck | null;
  cards: Card[];
  errors: string[];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((item) => typeof item === 'string' && item.length > 0);
}

/** Валидация одного файла колоды: схема, поля, дубликаты id внутри файла. */
export function parseDeckFile(raw: unknown, source: string): ParseResult {
  const errors: string[] = [];
  if (!isRecord(raw)) {
    return { deck: null, cards: [], errors: [`${source}: файл колоды должен быть объектом`] };
  }

  const deckRaw = raw.deck;
  const cardsRaw = raw.cards;
  if (!isRecord(deckRaw)) {
    errors.push(`${source}: отсутствует объект deck`);
    return { deck: null, cards: [], errors };
  }
  if (!Array.isArray(cardsRaw)) {
    errors.push(`${source}: cards должен быть массивом`);
    return { deck: null, cards: [], errors };
  }

  const id = typeof deckRaw.id === 'string' ? deckRaw.id : '';
  const title = typeof deckRaw.title === 'string' ? deckRaw.title : '';
  const description = typeof deckRaw.description === 'string' ? deckRaw.description : '';
  if (!id) errors.push(`${source}: deck.id не задан`);
  if (!title) errors.push(`${source}: deck.title не задан`);
  if (!description) errors.push(`${source}: deck.description не задан`);
  if (!isStringArray(deckRaw.tags)) errors.push(`${source}: deck.tags должен быть непустым массивом строк`);
  if (typeof deckRaw.adult !== 'boolean') errors.push(`${source}: deck.adult должен быть boolean`);

  const deck: Deck = {
    id,
    title,
    description,
    tags: isStringArray(deckRaw.tags) ? deckRaw.tags : [],
    adult: deckRaw.adult === true,
  };

  const cards: Card[] = [];
  const seenIds = new Set<string>();

  cardsRaw.forEach((entry, index) => {
    const where = `${source}: карточка #${index + 1}`;
    if (!isRecord(entry)) {
      errors.push(`${where}: должна быть объектом`);
      return;
    }

    const cardErrors: string[] = [];
    const cardId = typeof entry.id === 'string' ? entry.id : '';
    if (!cardId) cardErrors.push('id не задан');
    if (seenIds.has(cardId)) cardErrors.push(`повторяющийся id ${cardId}`);
    seenIds.add(cardId);

    if (entry.deckId !== deck.id) cardErrors.push(`deckId не совпадает с колодой ${deck.id}`);
    if (typeof entry.version !== 'number' || entry.version < 1) {
      cardErrors.push('version должна быть числом >= 1');
    }
    const kind = entry.type;
    if (typeof kind !== 'string' || !KINDS.includes(kind as CardKind)) {
      cardErrors.push(`type должен быть одним из ${KINDS.join(', ')}`);
    }
    const depth = entry.depth;
    if (typeof depth !== 'string' || !DEPTHS.includes(depth as Depth)) {
      cardErrors.push(`depth должен быть одним из ${DEPTHS.join(', ')}`);
    }
    if (typeof entry.adult !== 'boolean') cardErrors.push('adult должен быть boolean');
    if (!isStringArray(entry.tags)) cardErrors.push('tags должен быть непустым массивом строк');
    if (typeof entry.prompt !== 'string' || entry.prompt.trim().length < 10) {
      cardErrors.push('prompt должен быть осмысленным текстом');
    }
    if (entry.followUp !== undefined && (typeof entry.followUp !== 'string' || entry.followUp.trim().length === 0)) {
      cardErrors.push('followUp должен быть непустой строкой, если задан');
    }

    const adult = entry.adult === true;
    const intimacy = entry.intimacyLevel ?? null;
    if (adult) {
      if (intimacy === null || !INTIMACY.includes(intimacy as IntimacyLevel)) {
        cardErrors.push('у взрослой карточки должен быть intimacyLevel soft|frank');
      }
      if (!deck.adult) cardErrors.push('взрослая карточка не может лежать во взрослой колоде = false');
    } else if (intimacy !== null) {
      cardErrors.push('у обычной карточки intimacyLevel должен быть null');
    }

    const options = entry.options;
    if (kind === 'choice') {
      if (!Array.isArray(options) || options.length < 2 || !isStringArray(options)) {
        cardErrors.push('для choice нужны минимум два варианта');
      }
    } else if (options !== undefined) {
      cardErrors.push('options допустимы только для choice');
    }

    if (cardErrors.length > 0) {
      errors.push(`${where}: ${cardErrors.join('; ')}`);
      return;
    }

    const common = {
      id: cardId,
      deckId: deck.id,
      version: entry.version as number,
      depth: depth as Depth,
      adult,
      intimacyLevel: (intimacy as IntimacyLevel | null) ?? null,
      tags: entry.tags as string[],
      prompt: entry.prompt as string,
      ...(typeof entry.followUp === 'string' ? { followUp: entry.followUp } : {}),
    };

    if (kind === 'choice') {
      cards.push({ ...common, type: 'choice', options: options as string[] });
    } else if (kind === 'action') {
      cards.push({ ...common, type: 'action' });
    } else {
      cards.push({ ...common, type: 'open' });
    }
  });

  return { deck: errors.some((e) => e.includes('deck.')) ? null : deck, cards, errors };
}

/** Сквозная проверка реестра: дубликаты id, ссылки на колоды, счётчики. */
export function validateRegistry(entries: ParseResult[]): string[] {
  const errors: string[] = [];
  const ids = new Set<string>();
  const deckIds = new Set<string>();

  for (const entry of entries) {
    if (!entry.deck) {
      errors.push('колода не прошла валидацию');
      continue;
    }
    if (deckIds.has(entry.deck.id)) errors.push(`повторяющийся deckId ${entry.deck.id}`);
    deckIds.add(entry.deck.id);
    for (const card of entry.cards) {
      if (ids.has(card.id)) errors.push(`повторяющийся cardId ${card.id}`);
      ids.add(card.id);
      if (!deckIds.has(card.deckId) && card.deckId !== entry.deck.id) {
        errors.push(`сломанная ссылка: ${card.id} -> ${card.deckId}`);
      }
    }
  }
  return errors;
}
