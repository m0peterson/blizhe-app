import type { Card, Deck } from './types';

function matches(card: Card, deck: Deck | undefined, needle: string): boolean {
  const haystack = [
    card.prompt,
    card.followUp ?? '',
    card.tags.join(' '),
    deck?.title ?? '',
    deck?.description ?? '',
  ]
    .join(' ')
    .toLowerCase();
  return haystack.includes(needle);
}

/** Поиск по текстам карточек и тегам. Пустой запрос возвращает все карточки. */
export function searchCards(cards: Card[], decks: Map<string, Deck>, query: string): Card[] {
  const needle = query.trim().toLowerCase();
  if (needle.length === 0) return cards;
  return cards.filter((card) => matches(card, decks.get(card.deckId), needle));
}
