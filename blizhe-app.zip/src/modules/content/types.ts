/**
 * Доменные типы контента. Колоды хранятся отдельными JSON-файлами и
 * подключаются через реестр, без изменений движка и экранов.
 */

export type Depth = 'light' | 'personal' | 'deep';
export type IntimacyLevel = 'soft' | 'frank';
export type CardKind = 'open' | 'choice' | 'action';

export interface CardCommon {
  /** Стабильный идентификатор, не меняется между версиями контента. */
  id: string;
  deckId: string;
  /** Версия формулировки карточки. */
  version: number;
  depth: Depth;
  adult: boolean;
  /** Уровень откровенности заполнен только у карточек взрослого раздела. */
  intimacyLevel: IntimacyLevel | null;
  tags: string[];
  prompt: string;
  /** Не более одного уточняющего вопроса. */
  followUp?: string;
}

export interface OpenCard extends CardCommon {
  type: 'open';
}

export interface ChoiceCard extends CardCommon {
  type: 'choice';
  options: string[];
}

export interface ActionCard extends CardCommon {
  type: 'action';
}

export type Card = OpenCard | ChoiceCard | ActionCard;

export interface Deck {
  id: string;
  title: string;
  description: string;
  tags: string[];
  adult: boolean;
}

export interface DeckFile {
  deck: Deck;
  cards: Card[];
}
