import type { IntimacyLevel } from '../content/types';
import type { Preferences } from './types';
import { DEFAULT_PREFERENCES } from './types';

/** Включение взрослого раздела требует 18+ и явного выбора откровенности. */
export function setAdultMode(
  prefs: Preferences,
  enabled: boolean,
  intimacy: IntimacyLevel | null,
): Preferences {
  if (!enabled) {
    return { ...prefs, adultEnabled: false, intimacyLevel: null };
  }
  if (intimacy === null) {
    throw new Error('Для взрослого раздела нужен выбранный уровень откровенности');
  }
  return { ...prefs, adultEnabled: true, intimacyLevel: intimacy };
}

export function hideCard(prefs: Preferences, cardId: string): Preferences {
  return prefs.hiddenCardIds.includes(cardId)
    ? prefs
    : { ...prefs, hiddenCardIds: [...prefs.hiddenCardIds, cardId] };
}

export function unhideCard(prefs: Preferences, cardId: string): Preferences {
  return { ...prefs, hiddenCardIds: prefs.hiddenCardIds.filter((id) => id !== cardId) };
}

export function hideDeck(prefs: Preferences, deckId: string): Preferences {
  return prefs.hiddenDeckIds.includes(deckId)
    ? prefs
    : { ...prefs, hiddenDeckIds: [...prefs.hiddenDeckIds, deckId] };
}

export function unhideDeck(prefs: Preferences, deckId: string): Preferences {
  return { ...prefs, hiddenDeckIds: prefs.hiddenDeckIds.filter((id) => id !== deckId) };
}

export function setNames(prefs: Preferences, nameA: string, nameB: string): Preferences {
  return { ...prefs, nameA: nameA.trim(), nameB: nameB.trim() };
}

export function setAllowRepeats(prefs: Preferences, allowRepeats: boolean): Preferences {
  return { ...prefs, allowRepeats };
}

/** Полный сброс возвращает взрослый раздел в выключенное состояние. */
export function resetPreferences(): Preferences {
  return { ...DEFAULT_PREFERENCES };
}
