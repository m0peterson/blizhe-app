import type { IntimacyLevel } from '../content/types';

export interface Preferences {
  /** Версия схемы пользовательских данных, не контента. */
  schemaVersion: number;
  adultEnabled: boolean;
  intimacyLevel: IntimacyLevel | null;
  hiddenDeckIds: string[];
  hiddenCardIds: string[];
  nameA: string;
  nameB: string;
  allowRepeats: boolean;
}

export const USER_SCHEMA_VERSION = 1;

export const DEFAULT_PREFERENCES: Preferences = {
  schemaVersion: USER_SCHEMA_VERSION,
  adultEnabled: false,
  intimacyLevel: null,
  hiddenDeckIds: [],
  hiddenCardIds: [],
  nameA: '',
  nameB: '',
  allowRepeats: false,
};
