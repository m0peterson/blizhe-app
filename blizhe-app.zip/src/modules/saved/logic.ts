import type { Note, NoteKind, SavedState } from './types';
import { EMPTY_SAVED } from './types';

export { EMPTY_SAVED };

export function toggleFavorite(state: SavedState, cardId: string): SavedState {
  const favorites = state.favorites.includes(cardId)
    ? state.favorites.filter((id) => id !== cardId)
    : [...state.favorites, cardId];
  return { ...state, favorites };
}

export function toggleDeferred(state: SavedState, cardId: string): SavedState {
  const deferred = state.deferred.includes(cardId)
    ? state.deferred.filter((id) => id !== cardId)
    : [...state.deferred, cardId];
  return { ...state, deferred };
}

export function addNote(
  state: SavedState,
  input: { kind: NoteKind; text: string; cardId: string | null },
  now: number,
  id: string,
): SavedState {
  const note: Note = {
    id,
    kind: input.kind,
    text: input.text.trim(),
    cardId: input.cardId,
    createdAt: now,
    updatedAt: now,
    done: false,
  };
  return { ...state, notes: [note, ...state.notes] };
}

export function updateNote(state: SavedState, id: string, text: string, now: number): SavedState {
  return {
    ...state,
    notes: state.notes.map((note) =>
      note.id === id ? { ...note, text: text.trim(), updatedAt: now } : note,
    ),
  };
}

export function deleteNote(state: SavedState, id: string): SavedState {
  return { ...state, notes: state.notes.filter((note) => note.id !== id) };
}

export function toggleNoteDone(state: SavedState, id: string, now: number): SavedState {
  return {
    ...state,
    notes: state.notes.map((note) =>
      note.id === id ? { ...note, done: !note.done, updatedAt: now } : note,
    ),
  };
}

export function notesByKind(state: SavedState, kind: NoteKind): Note[] {
  return state.notes.filter((note) => note.kind === kind);
}
