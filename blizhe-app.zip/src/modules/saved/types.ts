export type NoteKind = 'learned' | 'agreement' | 'idea';

export interface Note {
  id: string;
  kind: NoteKind;
  text: string;
  /** Заметка может быть связана с карточкой, но не обязана. */
  cardId: string | null;
  createdAt: number;
  updatedAt: number;
  done: boolean;
}

export interface SavedState {
  schemaVersion: number;
  favorites: string[];
  deferred: string[];
  notes: Note[];
}

export const EMPTY_SAVED: SavedState = {
  schemaVersion: 1,
  favorites: [],
  deferred: [],
  notes: [],
};

export const NOTE_KIND_LABELS: Record<NoteKind, string> = {
  learned: 'Узнали друг о друге',
  agreement: 'Договорились',
  idea: 'Идеи подарков и желаний',
};
