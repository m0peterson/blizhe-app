import type { Card } from '../content/types';
import type { Preferences } from '../preferences/types';
import { isCardEligible } from './filter';
import type { AdvanceAction, Responder, SessionState } from './types';

export function createSession(
  queue: Card[],
  filter: SessionState['filter'],
  firstResponder: Responder,
  now: number,
  id: string,
): SessionState {
  return {
    id,
    filter,
    queue,
    index: 0,
    states: {},
    firstResponder,
    startedAt: now,
    updatedAt: now,
    finished: false,
  };
}

export function currentCard(state: SessionState): Card | null {
  return state.queue[state.index] ?? null;
}

export function responderFor(state: SessionState): Responder {
  return state.index % 2 === 0 ? state.firstResponder : state.firstResponder === 'a' ? 'b' : 'a';
}

export function progress(state: SessionState): { current: number; total: number } {
  return { current: Math.min(state.index + 1, state.queue.length), total: state.queue.length };
}

/**
 * Переход вперёд. Повторное решение после «Назад» учитывается: последнее
 * действие по карточке перезаписывает предыдущее.
 */
export function advance(state: SessionState, action: AdvanceAction, now: number): SessionState {
  const card = currentCard(state);
  if (!card || state.finished) return state;

  const states = { ...state.states, [card.id]: action };
  return {
    ...state,
    states,
    index: state.index + 1,
    updatedAt: now,
  };
}

/** Назад возвращает к карточке для перечитывания; повторное решение учитывается. */
export function goBack(state: SessionState, now: number): SessionState {
  if (state.index === 0 || state.finished) return state;
  return { ...state, index: state.index - 1, updatedAt: now };
}

export function finish(state: SessionState, now: number): SessionState {
  return { ...state, finished: true, updatedAt: now };
}

/**
 * Новые ограничения пользователя сильнее сохранённой очереди: карточки,
 * ставшие неподходящими (например, после выключения взрослого раздела),
 * удаляются из текущей сессии.
 */
export function reapplyConstraints(
  state: SessionState,
  prefs: Preferences,
  now: number,
): SessionState {
  const current = currentCard(state);
  const queue = state.queue.filter((card) => isCardEligible(card, { prefs, filter: state.filter }));
  if (queue.length === state.queue.length) return state;

  const newIndex = current ? Math.max(0, queue.findIndex((card) => card.id === current.id)) : 0;
  const states: SessionState['states'] = {};
  for (const card of queue) {
    const saved = state.states[card.id];
    if (saved) states[card.id] = saved;
  }

  return {
    ...state,
    queue,
    index: newIndex === -1 ? Math.min(state.index, queue.length) : newIndex,
    states,
    updatedAt: now,
  };
}

export function isComplete(state: SessionState): boolean {
  return state.finished || state.index >= state.queue.length;
}
