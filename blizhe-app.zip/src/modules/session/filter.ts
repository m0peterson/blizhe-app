import type { Card } from '../content/types';
import type { EligibilityContext } from './types';

const DEPTH_RANK: Record<Card['depth'], number> = { light: 0, personal: 1, deep: 2 };

export function depthRank(depth: Card['depth']): number {
  return DEPTH_RANK[depth];
}

/** Глубина и интимность независимы: глубокий разговор не обязан быть откровенным. */
export function isCardEligible(card: Card, ctx: EligibilityContext): boolean {
  const { prefs, filter } = ctx;

  if (prefs.hiddenCardIds.includes(card.id)) return false;
  if (prefs.hiddenDeckIds.includes(card.deckId)) return false;
  if (filter.deckIds.length > 0 && !filter.deckIds.includes(card.deckId)) return false;
  if (depthRank(card.depth) > depthRank(filter.maxDepth)) return false;

  if (card.adult) {
    if (!filter.includeAdult || !prefs.adultEnabled) return false;
    if (prefs.intimacyLevel === null) return false;
    if (prefs.intimacyLevel === 'soft' && card.intimacyLevel !== 'soft') return false;
  }

  return true;
}

export function filterCards(cards: Card[], ctx: EligibilityContext): Card[] {
  return cards.filter((card) => isCardEligible(card, ctx));
}
