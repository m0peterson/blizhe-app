import type { Card } from '../content/types';
import type { EligibilityContext, QueueOptions, QueueResult } from './types';
import { filterCards, depthRank } from './filter';

function shuffle<T>(items: T[], rng: () => number): T[] {
  const result = items.slice();
  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    const swap = result[i];
    result[i] = result[j];
    result[j] = swap;
  }
  return result;
}

/** Чередование тем внутри одного уровня глубины: без пачек подряд из одной темы. */
function interleaveByDeck(cards: Card[], rng: () => number): Card[] {
  const byDeck = new Map<string, Card[]>();
  for (const card of shuffle(cards, rng)) {
    const bucket = byDeck.get(card.deckId) ?? [];
    bucket.push(card);
    byDeck.set(card.deckId, bucket);
  }
  const queues = [...byDeck.values()];
  const result: Card[] = [];
  while (result.length < cards.length) {
    for (const queue of queues) {
      const next = queue.shift();
      if (next) result.push(next);
    }
  }
  return result;
}

/**
 * Сначала фильтрация, затем сортировка от лёгких к личным и только потом
 * перемешивание в пределах уровня глубины.
 * При preferUnseen сначала идут непоказанные; при preferUnseen=false
 * предпочтений нет — вся подходящая библиотека мешается равномерно.
 */
export function buildQueue(
  cards: Card[],
  ctx: EligibilityContext,
  options: QueueOptions,
): QueueResult {
  const eligible = filterCards(cards, ctx);
  const eligibleIds = new Set(eligible.map((card) => card.id));

  if (!options.preferUnseen) {
    const mixed = orderByDepthThenMix(eligible, options.rng);
    const queue = mixed.slice(0, options.count);
    const shortfall = Math.max(0, options.count - queue.length);
    const reason: QueueResult['reason'] =
      eligibleIds.size === 0 ? 'empty' : shortfall > 0 ? 'short' : 'ok';
    return { queue, shortfall, totalEligible: eligibleIds.size, reason, repeatsUsed: false };
  }

  const unseen = eligible.filter((card) => !options.seenIds.includes(card.id));
  const seen = eligible.filter((card) => options.seenIds.includes(card.id));

  const orderedUnseen = orderByDepthThenMix(unseen, options.rng);
  const orderedSeen = orderByDepthThenMix(seen, options.rng);

  const queue = orderedUnseen.slice(0, options.count);
  let repeatsUsed = false;

  if (queue.length < options.count && options.allowRepeats) {
    const extra = orderedSeen.filter((card) => !queue.some((item) => item.id === card.id));
    queue.push(...extra.slice(0, options.count - queue.length));
    repeatsUsed = extra.length > 0;
  }

  const shortfall = Math.max(0, options.count - queue.length);
  const reason: QueueResult['reason'] =
    eligibleIds.size === 0 ? 'empty' : shortfall > 0 ? 'short' : 'ok';

  return {
    queue,
    shortfall,
    totalEligible: eligibleIds.size,
    reason,
    repeatsUsed,
  };
}

function orderByDepthThenMix(cards: Card[], rng: () => number): Card[] {
  const bands = new Map<number, Card[]>();
  for (const card of cards) {
    const band = bands.get(depthRank(card.depth)) ?? [];
    band.push(card);
    bands.set(depthRank(card.depth), band);
  }
  return [...bands.keys()]
    .sort((a, b) => a - b)
    .flatMap((key) => interleaveByDeck(bands.get(key) ?? [], rng));
}
