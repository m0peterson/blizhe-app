import type { Card, Depth } from '../content/types';
import type { Preferences } from '../preferences/types';

export interface SessionFilter {
  /** Пустой список означает «все темы». */
  deckIds: string[];
  maxDepth: Depth;
  includeAdult: boolean;
}

/** Пропуск не является ответом: состояния различаются явно. */
export type CardState = 'shown' | 'discussed' | 'skipped' | 'deferred';

export type AdvanceAction = 'discussed' | 'skipped' | 'deferred';

export type Responder = 'a' | 'b';

export interface SessionState {
  id: string;
  filter: SessionFilter;
  /** Снимок карточек, зафиксированный при старте. */
  queue: Card[];
  index: number;
  states: Record<string, CardState>;
  firstResponder: Responder;
  startedAt: number;
  updatedAt: number;
  finished: boolean;
}

export interface EligibilityContext {
  prefs: Preferences;
  filter: SessionFilter;
}

export interface QueueOptions {
  count: number;
  preferUnseen: boolean;
  seenIds: string[];
  allowRepeats: boolean;
  rng: () => number;
}

export interface QueueResult {
  queue: Card[];
  shortfall: number;
  totalEligible: number;
  reason: 'ok' | 'short' | 'empty';
  repeatsUsed: boolean;
}
