import styles from './BottomNav.module.css';

export type NavKey = 'home' | 'topics' | 'our' | 'settings';

interface BottomNavProps {
  current: NavKey;
  onNavigate: (key: NavKey) => void;
}

const ITEMS: Array<{ key: NavKey; label: string; testId: string }> = [
  { key: 'home', label: 'Начать', testId: 'nav-home' },
  { key: 'topics', label: 'Темы', testId: 'nav-topics' },
  { key: 'our', label: 'Наше', testId: 'nav-our' },
  { key: 'settings', label: 'Настройки', testId: 'nav-settings' },
];

export function BottomNav({ current, onNavigate }: BottomNavProps) {
  return (
    <nav aria-label="Основная навигация" className={styles.nav}>
      {ITEMS.map((item) => (
        <button
          key={item.key}
          type="button"
          data-testid={item.testId}
          aria-current={current === item.key ? 'page' : undefined}
          className={current === item.key ? `${styles.item} ${styles.current}` : styles.item}
          onClick={() => onNavigate(item.key)}
        >
          {item.label}
        </button>
      ))}
    </nav>
  );
}
