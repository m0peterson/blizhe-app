import { useState } from 'react';
import styles from './CardView.module.css';

export type CardViewDepth = 'light' | 'personal' | 'deep';
export type CardViewKind = 'open' | 'choice' | 'action';

/** Минимальные данные карточки для отображения; без зависимости от домена контента. */
export interface CardViewData {
  id: string;
  depth: CardViewDepth;
  prompt: string;
  type: CardViewKind;
  options?: string[];
  followUp?: string;
}

export function depthLabel(depth: CardViewDepth): string {
  if (depth === 'light') return 'Легко';
  if (depth === 'personal') return 'Лично';
  return 'Глубоко';
}

interface CardViewProps {
  card: CardViewData;
  deckTitle: string;
  promptTestId?: string;
}

export function CardView({ card, deckTitle, promptTestId }: CardViewProps) {
  const [followUpOpen, setFollowUpOpen] = useState(false);
  return (
    <article className={styles.card} aria-labelledby={`card-${card.id}`}>
      <div className={styles.meta}>
        <span className={styles.deck}>{deckTitle}</span>
        <span className={styles.depth}>{depthLabel(card.depth)}</span>
      </div>
      <h2 id={`card-${card.id}`} data-testid={promptTestId} className={styles.prompt}>
        {card.prompt}
      </h2>
      {card.type === 'choice' && card.options ? (
        <ul className={styles.options} aria-label="Варианты для обсуждения">
          {card.options.map((option) => (
            <li key={option} className={styles.option}>
              {option}
            </li>
          ))}
        </ul>
      ) : null}
      {card.followUp ? (
        <div className={styles.followUp}>
          {!followUpOpen ? (
            <button
              type="button"
              className={styles.followUpToggle}
              onClick={() => setFollowUpOpen(true)}
              aria-expanded="false"
            >
              Уточняющий вопрос
            </button>
          ) : (
            <p aria-expanded="true">
              <span className={styles.followUpLabel}>Уточнение: </span>
              {card.followUp}
            </p>
          )}
        </div>
      ) : null}
    </article>
  );
}
