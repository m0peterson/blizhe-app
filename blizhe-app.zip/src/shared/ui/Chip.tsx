import type { ReactNode } from 'react';
import styles from './Chip.module.css';

interface ChipProps {
  selected?: boolean;
  onClick?: () => void;
  testId?: string;
  children: ReactNode;
}

export function Chip({ selected, onClick, testId, children }: ChipProps) {
  return (
    <button
      type="button"
      data-testid={testId}
      aria-pressed={selected ?? undefined}
      className={selected ? `${styles.chip} ${styles.selected}` : styles.chip}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
