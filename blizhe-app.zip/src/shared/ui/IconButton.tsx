import type { ButtonHTMLAttributes } from 'react';
import styles from './IconButton.module.css';

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  active?: boolean;
}

export function IconButton({ label, active, className, children, type = 'button', ...rest }: IconButtonProps) {
  const cls = [styles.iconButton, active ? styles.active : '', className ?? ''].filter(Boolean).join(' ');
  return (
    <button type={type} aria-label={label} aria-pressed={active} className={cls} {...rest}>
      {children}
    </button>
  );
}
