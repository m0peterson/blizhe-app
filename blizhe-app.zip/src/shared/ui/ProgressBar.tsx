import styles from './ProgressBar.module.css';

interface ProgressBarProps {
  current: number;
  total: number;
  testId?: string;
}

export function ProgressBar({ current, total, testId }: ProgressBarProps) {
  const pct = total === 0 ? 0 : Math.min(100, Math.round((current / total) * 100));
  return (
    <div
      className={styles.wrap}
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={total}
      aria-valuenow={current}
      aria-label={`Прогресс: ${current} из ${total}`}
      data-testid={testId}
    >
      <div className={styles.track}>
        <div className={styles.fill} style={{ width: `${pct}%` }} />
      </div>
      <span className={styles.label}>
        {current}/{total}
      </span>
    </div>
  );
}
