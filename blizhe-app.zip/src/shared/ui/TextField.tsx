import styles from './TextField.module.css';

interface TextFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  multiline?: boolean;
  rows?: number;
  testId?: string;
  hint?: string;
  maxLength?: number;
}

export function TextField({
  label,
  value,
  onChange,
  placeholder,
  multiline,
  rows = 3,
  testId,
  hint,
  maxLength = 2000,
}: TextFieldProps) {
  const id = testId ?? `field-${label}`;
  return (
    <label className={styles.wrap} htmlFor={id}>
      <span className={styles.label}>{label}</span>
      {multiline ? (
        <textarea
          id={id}
          data-testid={testId}
          className={styles.input}
          value={value}
          rows={rows}
          maxLength={maxLength}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : (
        <input
          id={id}
          data-testid={testId}
          className={styles.input}
          type="text"
          value={value}
          maxLength={maxLength}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
      {hint ? <span className={styles.hint}>{hint}</span> : null}
    </label>
  );
}
