import { describe, expect, it } from 'vitest';
import { CONTENT_VERSION, cardById, cards, deckById, decks } from '../src/modules/content';

describe('content validation', () => {
  it('библиотека: 12 колод и 120 карточек', () => {
    expect(decks).toHaveLength(12);
    expect(cards).toHaveLength(120);
    expect(CONTENT_VERSION).toBe(1);
  });

  it('id глобально уникальны', () => {
    const ids = cards.map((c) => c.id);
    expect(new Set(ids).size).toBe(ids.length);
    const deckIds = decks.map((d) => d.id);
    expect(new Set(deckIds).size).toBe(deckIds.length);
  });

  it('ссылки deckId существуют', () => {
    for (const card of cards) {
      expect(deckById.has(card.deckId), `сломанная ссылка: ${card.id} -> ${card.deckId}`).toBe(true);
      expect(cardById.get(card.id)).toBeDefined();
    }
  });

  it('ровно 10 карточек на колоду', () => {
    for (const deck of decks) {
      const count = cards.filter((c) => c.deckId === deck.id).length;
      expect(count, `колода ${deck.id}`).toBe(10);
    }
  });

  it('глубина, типы и интимность по правилам', () => {
    for (const card of cards) {
      expect(['light', 'personal', 'deep']).toContain(card.depth);
      expect(['open', 'choice', 'action']).toContain(card.type);
      expect(card.prompt.trim().length).toBeGreaterThanOrEqual(10);
      if (card.followUp !== undefined) {
        expect(typeof card.followUp).toBe('string');
        expect(card.followUp.trim().length).toBeGreaterThan(0);
      }
      if (card.type === 'choice') {
        expect('options' in card).toBe(true);
        const options = (card as { options?: unknown }).options;
        expect(Array.isArray(options)).toBe(true);
        expect((options as string[]).length).toBeGreaterThanOrEqual(2);
      } else {
        expect('options' in card).toBe(false);
      }
      if (card.adult) {
        expect(['soft', 'frank']).toContain(card.intimacyLevel);
      } else {
        expect(card.intimacyLevel).toBeNull();
      }
    }
  });

  it('ровно одна взрослая колода seks, 5 soft + 5 frank', () => {
    const adultDecks = decks.filter((d) => d.adult);
    expect(adultDecks.map((d) => d.id)).toEqual(['seks']);
    const adultCards = cards.filter((c) => c.adult);
    expect(adultCards.length).toBe(10);
    expect(adultCards.every((c) => c.deckId === 'seks')).toBe(true);
    expect(adultCards.filter((c) => c.intimacyLevel === 'soft')).toHaveLength(5);
    expect(adultCards.filter((c) => c.intimacyLevel === 'frank')).toHaveLength(5);
  });

  it('в каждой колоде минимум 2 light / 2 personal / 2 deep и есть choice + action', () => {
    for (const deck of decks) {
      const list = cards.filter((c) => c.deckId === deck.id);
      expect(list.filter((c) => c.depth === 'light').length).toBeGreaterThanOrEqual(2);
      expect(list.filter((c) => c.depth === 'personal').length).toBeGreaterThanOrEqual(2);
      expect(list.filter((c) => c.depth === 'deep').length).toBeGreaterThanOrEqual(2);
      expect(list.some((c) => c.type === 'choice'), `нет choice в ${deck.id}`).toBe(true);
      expect(list.some((c) => c.type === 'action'), `нет action в ${deck.id}`).toBe(true);
    }
  });

  it('prompt без обвинительных маркеров и дубликатов по смыслу (грубо)', () => {
    const prompts = cards.map((c) => c.prompt.trim().toLowerCase());
    expect(new Set(prompts).size).toBe(prompts.length);
  });
});
