import { describe, expect, it } from 'vitest';
import { DEFAULT_PREFERENCES } from '../src/modules/preferences/types';
import { hideCard, hideDeck, resetPreferences, setAdultMode, setAllowRepeats, setNames, unhideCard, unhideDeck } from '../src/modules/preferences/logic';

describe('preferences', () => {
  it('взрослый режим требует откровенности и выключается в false', () => {
    expect(() => setAdultMode(DEFAULT_PREFERENCES, true, null)).toThrow();
    const on = setAdultMode(DEFAULT_PREFERENCES, true, 'soft');
    expect(on.adultEnabled).toBe(true);
    expect(on.intimacyLevel).toBe('soft');
    const off = setAdultMode(on, false, null);
    expect(off.adultEnabled).toBe(false);
    expect(off.intimacyLevel).toBeNull();
  });

  it('скрытия добавляются без дублей и снимаются', () => {
    let prefs = hideCard(DEFAULT_PREFERENCES, 'c-1');
    prefs = hideCard(prefs, 'c-1');
    expect(prefs.hiddenCardIds).toEqual(['c-1']);
    prefs = unhideCard(prefs, 'c-1');
    expect(prefs.hiddenCardIds).toEqual([]);

    prefs = hideDeck(prefs, 'byt');
    prefs = hideDeck(prefs, 'byt');
    expect(prefs.hiddenDeckIds).toEqual(['byt']);
    prefs = unhideDeck(prefs, 'byt');
    expect(prefs.hiddenDeckIds).toEqual([]);
  });

  it('имена триммятся, повторы переключаются, сброс гасит взрослый раздел', () => {
    const named = setNames(DEFAULT_PREFERENCES, '  Анна ', 'Борис  ');
    expect(named.nameA).toBe('Анна');
    expect(named.nameB).toBe('Борис');
    expect(setAllowRepeats(DEFAULT_PREFERENCES, true).allowRepeats).toBe(true);
    const on = setAdultMode(DEFAULT_PREFERENCES, true, 'frank');
    expect(resetPreferences()).toEqual(DEFAULT_PREFERENCES);
    expect(resetPreferences().adultEnabled).toBe(false);
    expect(on.adultEnabled).toBe(true);
  });
});
