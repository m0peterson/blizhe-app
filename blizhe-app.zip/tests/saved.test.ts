import { describe, expect, it } from 'vitest';
import { EMPTY_SAVED, addNote, deleteNote, notesByKind, toggleDeferred, toggleFavorite, toggleNoteDone, updateNote } from '../src/modules/saved/logic';

describe('saved', () => {
  it('избранное и отложенное переключаются', () => {
    const once = toggleFavorite(EMPTY_SAVED, 'c-1');
    expect(once.favorites).toContain('c-1');
    expect(toggleFavorite(once, 'c-1').favorites).not.toContain('c-1');

    const deferred = toggleDeferred(EMPTY_SAVED, 'c-2');
    expect(deferred.deferred).toContain('c-2');
    expect(toggleDeferred(deferred, 'c-2').deferred).not.toContain('c-2');
  });

  it('заметки трёх видов: создание, редактура, done только у договорённостей (логика UI)', () => {
    let state = addNote(EMPTY_SAVED, { kind: 'learned', text: '  Узнали, что любит чай  ', cardId: null }, 1000, 'n1');
    state = addNote(state, { kind: 'agreement', text: 'Гуляем вместе в субботу', cardId: 'c-1' }, 1001, 'n2');
    state = addNote(state, { kind: 'idea', text: 'Книга в подарок', cardId: null }, 1002, 'n3');

    expect(notesByKind(state, 'learned')).toHaveLength(1);
    expect(notesByKind(state, 'agreement')).toHaveLength(1);
    expect(notesByKind(state, 'idea')).toHaveLength(1);
    // Текст триммится при создании.
    expect(notesByKind(state, 'learned')[0]?.text).toBe('Узнали, что любит чай');

    state = updateNote(state, 'n1', '  Узнали, что любит чай с мятой ', 1003);
    expect(notesByKind(state, 'learned')[0]?.text).toBe('Узнали, что любит чай с мятой');

    state = toggleNoteDone(state, 'n2', 1004);
    expect(notesByKind(state, 'agreement')[0]?.done).toBe(true);

    state = deleteNote(state, 'n3');
    expect(notesByKind(state, 'idea')).toHaveLength(0);
  });
});
