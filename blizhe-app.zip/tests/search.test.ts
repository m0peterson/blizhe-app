import { describe, expect, it } from 'vitest';
import { searchCards } from '../src/modules/content/search';
import { cards, deckById } from '../src/modules/content/registry';

describe('search', () => {
  it('пустой запрос возвращает всё', () => {
    expect(searchCards(cards, deckById, '')).toHaveLength(cards.length);
    expect(searchCards(cards, deckById, '   ')).toHaveLength(cards.length);
  });

  it('поиск по тексту и тегам, регистронезависимо', () => {
    const first = cards[0];
    if (!first) throw new Error('нет карточек');
    const word = first.prompt.split(' ').find((w) => w.replace(/[^а-яёa-z]/gi, '').length > 4) ?? first.prompt.slice(0, 6);
    const found = searchCards(cards, deckById, word);
    expect(found.some((c) => c.id === first.id)).toBe(true);

    const byTag = searchCards(cards, deckById, first.tags[0] ?? '');
    if (first.tags[0]) {
      expect(byTag.some((c) => c.id === first.id)).toBe(true);
    }
  });

  it('ерунда ничего не находит', () => {
    expect(searchCards(cards, deckById, 'zzz-несуществующий-запрос-qqq')).toHaveLength(0);
  });
});
