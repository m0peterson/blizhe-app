import { describe, expect, it } from 'vitest';
import type { Card } from '../src/modules/content/types';
import { DEFAULT_PREFERENCES } from '../src/modules/preferences';
import type { Preferences } from '../src/modules/preferences';
import { buildQueue } from '../src/modules/session/queue';
import { advance, createSession, currentCard, finish, goBack, isComplete, reapplyConstraints, responderFor } from '../src/modules/session/engine';

function makeCard(partial: Partial<Card> & { id: string; deckId: string }): Card {
  return {
    version: 1,
    type: 'open',
    depth: 'light',
    adult: false,
    intimacyLevel: null,
    tags: ['t'],
    prompt: `Вопрос ${partial.id} достаточно длинный для валидации?`,
    ...partial,
  } as Card;
}

function prefs(overrides: Partial<Preferences> = {}): Preferences {
  return { ...DEFAULT_PREFERENCES, ...overrides };
}

// Детерминированная rng: всегда 0.5 — порядок предсказуем.
const rng = () => 0.5;

describe('session engine', () => {
  it('без повторов в сессии и очередь от лёгких к личным', () => {
    const all: Card[] = [
      makeCard({ id: 'a-1', deckId: 'd1', depth: 'deep' }),
      makeCard({ id: 'a-2', deckId: 'd1', depth: 'light' }),
      makeCard({ id: 'a-3', deckId: 'd2', depth: 'personal' }),
      makeCard({ id: 'a-4', deckId: 'd2', depth: 'light' }),
    ];
    const result = buildQueue(
      all,
      { prefs: prefs(), filter: { deckIds: [], maxDepth: 'deep', includeAdult: false } },
      { count: 4, preferUnseen: true, seenIds: [], allowRepeats: false, rng },
    );
    expect(result.queue).toHaveLength(4);
    expect(result.reason).toBe('ok');
    const ids = result.queue.map((c) => c.id);
    expect(new Set(ids).size).toBe(4);
    const ranks = result.queue.map((c) => (c.depth === 'light' ? 0 : c.depth === 'personal' ? 1 : 2));
    expect([...ranks].sort((a, b) => a - b)).toEqual(ranks);
  });

  it('preferUnseen и короткие/пустые библиотеки', () => {
    const all: Card[] = [makeCard({ id: 'b-1', deckId: 'd1' }), makeCard({ id: 'b-2', deckId: 'd1' })];
    const short = buildQueue(
      all,
      { prefs: prefs(), filter: { deckIds: [], maxDepth: 'deep', includeAdult: false } },
      { count: 5, preferUnseen: true, seenIds: [], allowRepeats: false, rng },
    );
    expect(short.reason).toBe('short');
    expect(short.shortfall).toBe(3);
    expect(short.totalEligible).toBe(2);

    const repeats = buildQueue(
      all,
      { prefs: prefs({ allowRepeats: true }), filter: { deckIds: [], maxDepth: 'deep', includeAdult: false } },
      { count: 2, preferUnseen: true, seenIds: ['b-1', 'b-2'], allowRepeats: true, rng },
    );
    expect(repeats.queue).toHaveLength(2);
    expect(repeats.repeatsUsed).toBe(true);

    const empty = buildQueue(
      [],
      { prefs: prefs(), filter: { deckIds: [], maxDepth: 'deep', includeAdult: false } },
      { count: 5, preferUnseen: true, seenIds: [], allowRepeats: false, rng },
    );
    expect(empty.reason).toBe('empty');
    expect(empty.queue).toHaveLength(0);
  });

  it('adult-gating во всех путях', () => {
    const adult = makeCard({ id: 's-1', deckId: 'seks', adult: true, intimacyLevel: 'frank' });
    const soft = makeCard({ id: 's-2', deckId: 'seks', adult: true, intimacyLevel: 'soft' });
    const plain = makeCard({ id: 'z-1', deckId: 'zabota' });
    const all = [adult, soft, plain];

    const off = buildQueue(
      all,
      { prefs: prefs(), filter: { deckIds: [], maxDepth: 'deep', includeAdult: true } },
      { count: 5, preferUnseen: true, seenIds: [], allowRepeats: false, rng },
    );
    expect(off.queue.map((c) => c.id)).toEqual(['z-1']);

    const softOnly = buildQueue(
      all,
      {
        prefs: prefs({ adultEnabled: true, intimacyLevel: 'soft' }),
        filter: { deckIds: [], maxDepth: 'deep', includeAdult: true },
      },
      { count: 5, preferUnseen: true, seenIds: [], allowRepeats: false, rng },
    );
    expect(softOnly.queue.map((c) => c.id).sort()).toEqual(['s-2', 'z-1'].sort());
  });

  it('back и двойное нажатие не ломают состояние', () => {
    const all = [makeCard({ id: 'c-1', deckId: 'd' }), makeCard({ id: 'c-2', deckId: 'd' })];
    let state = createSession(all, { deckIds: [], maxDepth: 'deep', includeAdult: false }, 'a', 1000, 's1');
    expect(currentCard(state)?.id).toBe('c-1');
    expect(responderFor(state)).toBe('a');

    state = advance(state, 'discussed', 1001);
    expect(currentCard(state)?.id).toBe('c-2');
    expect(responderFor(state)).toBe('b');

    // Повторное действие над той же карточкой учтено один раз: индекс вырос ровно на 1.
    const once = advance(state, 'discussed', 1002);
    expect(once.index).toBe(2);
    expect(isComplete(once)).toBe(true);

    const back = goBack(state, 1003);
    expect(currentCard(back)?.id).toBe('c-1');
    // Назад возвращает к карточке без удвоения прогресса; состояние сохраняется до нового решения.
    expect(back.states['c-1']).toBe('discussed');
    expect(back.index).toBe(0);

    // Повторное решение после «Назад» перезаписывает предыдущее.
    const redecided = advance(back, 'skipped', 1004);
    expect(redecided.states['c-1']).toBe('skipped');
    expect(redecided.index).toBe(1);

    const finished = finish(state, 1004);
    expect(advance(finished, 'discussed', 1005)).toBe(finished);
  });

  it('reapplyConstraints удаляет взрослые карточки из активной сессии', () => {
    const adult = makeCard({ id: 's-9', deckId: 'seks', adult: true, intimacyLevel: 'soft' });
    const plain = makeCard({ id: 'z-9', deckId: 'zabota' });
    let state = createSession(
      [adult, plain],
      { deckIds: [], maxDepth: 'deep', includeAdult: true },
      'a',
      1000,
      's2',
    );
    const off = prefs();
    state = reapplyConstraints(state, off, 1001);
    expect(state.queue.map((c) => c.id)).toEqual(['z-9']);
  });

  it('preferUnseen=false не предпочитает непоказанные', () => {
    const all: Card[] = [makeCard({ id: 'e-1', deckId: 'd1' }), makeCard({ id: 'e-2', deckId: 'd1' })];
    const ctx = { prefs: prefs(), filter: { deckIds: [] as string[], maxDepth: 'deep' as const, includeAdult: false } };
    // С предпочтением и всеми показанными без повторов очередь пуста.
    const withPref = buildQueue(all, ctx, {
      count: 1,
      preferUnseen: true,
      seenIds: ['e-1', 'e-2'],
      allowRepeats: false,
      rng,
    });
    expect(withPref.queue).toHaveLength(0);
    const noPref = buildQueue(all, ctx, {
      count: 1,
      preferUnseen: false,
      seenIds: ['e-1', 'e-2'],
      allowRepeats: false,
      rng,
    });
    // Без предпочтения очередь строится из всех подходящих, а не только из unseen (их нет).
    expect(noPref.queue).toHaveLength(1);
    expect(noPref.reason).toBe('ok');
    expect(noPref.repeatsUsed).toBe(false);
  });

  it('скрытия и темы фильтруются', () => {
    const all = [makeCard({ id: 'd-1', deckId: 'd1' }), makeCard({ id: 'd-2', deckId: 'd2' })];
    const result = buildQueue(
      all,
      {
        prefs: prefs({ hiddenCardIds: ['d-1'], hiddenDeckIds: ['d2'] }),
        filter: { deckIds: [], maxDepth: 'deep', includeAdult: false },
      },
      { count: 5, preferUnseen: true, seenIds: [], allowRepeats: false, rng },
    );
    expect(result.reason).toBe('empty');
  });
});
