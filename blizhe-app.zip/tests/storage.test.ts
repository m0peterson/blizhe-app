import { beforeEach, describe, expect, it } from 'vitest';
import { createMemoryKv } from '../src/infrastructure/storage/memoryKv';
import type { KvStore } from '../src/infrastructure/storage/kv';
import {
  clearAllUserData,
  loadMeta,
  loadPreferences,
  loadSaved,
  loadSession,
  markCardSeen,
  migrateMeta,
  migratePreferences,
  migrateSaved,
  saveMeta,
  savePreferences,
  saveSaved,
  saveSession,
} from '../src/infrastructure/storage/repositories';
import { createSession } from '../src/modules/session/engine';
import { DEFAULT_PREFERENCES } from '../src/modules/preferences/types';

describe('storage и миграции', () => {
  let store: KvStore;
  beforeEach(() => {
    store = createMemoryKv();
  });

  it('память: round-trip настроек, сессии, заметок и meta', async () => {
    await savePreferences(store, { ...DEFAULT_PREFERENCES, nameA: 'Анна' });
    expect((await loadPreferences(store)).nameA).toBe('Анна');

    await saveSaved(store, {
      schemaVersion: 1,
      favorites: ['c-1'],
      deferred: [],
      notes: [{ id: 'n1', kind: 'idea', text: 'Книга', cardId: null, createdAt: 1, updatedAt: 1, done: false }],
    });
    expect((await loadSaved(store)).notes).toHaveLength(1);

    const session = createSession([], { deckIds: [], maxDepth: 'light', includeAdult: false }, 'a', 1, 's1');
    await saveSession(store, session);
    expect((await loadSession(store))?.id).toBe('s1');

    await saveMeta(store, { seenCardIds: ['c-1'], contentVersion: 1 });
    expect((await loadMeta(store)).seenCardIds).toEqual(['c-1']);
  });

  it('markCardSeen не дублирует id', async () => {
    await markCardSeen(store, 'c-1');
    await markCardSeen(store, 'c-1');
    expect((await loadMeta(store)).seenCardIds).toEqual(['c-1']);
  });

  it('миграция не теряет заметки при старом формате', () => {
    const migrated = migrateSaved({
      favorites: ['c-1'],
      deferred: ['c-2'],
      notes: [{ id: 'n1', kind: 'agreement', text: 'Гулять', cardId: null, createdAt: 5, updatedAt: 6, done: false }],
    });
    expect(migrated.notes).toHaveLength(1);
    expect(migrated.notes[0]?.text).toBe('Гулять');
    expect(migrated.favorites).toEqual(['c-1']);
  });

  it('миграция чинит неконсистентные настройки и meta', () => {
    expect(migratePreferences(null).adultEnabled).toBe(false);
    expect(migratePreferences({ adultEnabled: true }).intimacyLevel).toBeNull();
    expect(migrateMeta(null).seenCardIds).toEqual([]);
  });

  it('clearAllUserData очищает всё', async () => {
    await savePreferences(store, { ...DEFAULT_PREFERENCES, nameA: 'x' });
    await saveSaved(store, {
      schemaVersion: 1,
      favorites: ['c-1'],
      deferred: [],
      notes: [{ id: 'n1', kind: 'idea', text: 't', cardId: null, createdAt: 1, updatedAt: 1, done: false }],
    });
    await clearAllUserData(store);
    expect((await loadPreferences(store)).nameA).toBe('');
    expect((await loadSaved(store)).notes).toHaveLength(0);
    expect(await loadSession(store)).toBeNull();
  });
});
